#include "ggml-shielded.h"
#ifdef SHIELDED_COMPACT
#include "shielded-compact.h"
#endif
#include "shielded-latency.h"
#include "shielded-group-key.h"
#include "shielded-fusion.h"
#include "shielded-weight-cache.h"
#include "shielded-encoded-source.h"
#include "ggml-backend-impl.h"
#include "ggml-impl.h"

extern "C" {
#include "shielded-field.h"
#include "shielded-tee.h"
#include "shielded-spill.h"
#include "shielded-overlap.h"
#include "shielded-parwork.h"
#include "shielded-wide.h"
}
#include "shielded-source-quant.h"

#include <chrono>
#include <cmath>
#include <cfloat>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <dlfcn.h>
#include <dirent.h>
#include <sched.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <map>
#include <memory>
#include <sstream>
#include <algorithm>
#include <mutex>
#include <set>
#include <string>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <thread>
#include <vector>
#include <unordered_map>

#define SH_LOG(...) do { if (sh_verbose()) fprintf(stderr, "[shielded] " __VA_ARGS__); } while (0)

static double sh_now_ms() { return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now().time_since_epoch()).count(); }

static bool sh_verbose() {
    static int v = -1;
    if (v < 0) { const char *e = getenv("SHIELDED_VERBOSE"); v = (e && *e && strcmp(e, "0")) ? 1 : 0; }
    return v != 0;
}
static int sh_env_int(const char *name, int dflt) {
    const char *e = getenv(name);
    return (e && *e) ? atoi(e) : dflt;
}

/* A process-wide correction to every site's calibrated activation exponent.
 * NOT per-request: a constant, exactly as the calibrated exponent is --
 * adapting it to the activation in hand would buy field headroom by leaking
 * activation magnitude, and is refused.
 *
 * It defaults to 0 because the calibration files are now produced by
 * shielded-calib, which encodes each weight with the very sh_prepare_weight_rows
 * this backend calls -- per OUTPUT COLUMN -- so the exponent it chooses is for
 * the product the runtime actually forms. The knob exists for history and for
 * experiments: the first calibrations came from calibrate.py, which measured
 * against tee.py's PER-TENSOR encoding, where most columns held tiny w_fixed and
 * tiny products; against per-column weights those exponents were 1-6 bits too
 * generous (Qwen2.5-0.5B, per site) and a blanket -5, sized for the worst site,
 * was what made them fit. Per-site calibration gives the median site 3 of those
 * bits back. A calibrate.py file still needs SHIELDED_AF_DELTA=-5.
 *
 * Getting this wrong does not silently corrupt anything -- the Freivalds check
 * runs over the integers and catches the wrap -- but it fails EVERY request,
 * which is how the -5 once shipped: verified locally with the flag set, deployed
 * without it, and the tenant died in llama_decode with the wrap detector doing
 * its job. */
static int sh_af_delta_env() {
    static int d = INT32_MIN;
    if (d == INT32_MIN) d = sh_env_int("SHIELDED_AF_DELTA", 0);
    return d;
}
struct sh_state;
static int64_t sh_af_delta(const sh_state &s);
static sh_window_fn g_win_fn; static void *g_win_ctx;   /* dealt pads: see ggml_backend_shielded_set_window_provider */
static ggml_shielded_weight_verifier g_weight_verifier;
static void *g_weight_verifier_ctx;
static ggml_shielded_source_release g_source_release;
static void *g_source_release_ctx;
static ggml_shielded_encoded_source g_encoded_source;   /* optional catalog hit path (shielded-encoded-source.h) */
static void *g_encoded_source_ctx;
static ggml_shielded_encoded_failure g_encoded_failure;  /* optional: names the tensor whose catalog artifact failed a verified read */
static void *g_encoded_failure_ctx;
static void sh_encoded_failed(const std::string &name, const char *why) { if (g_encoded_failure) g_encoded_failure(g_encoded_failure_ctx, name.c_str(), why); }
/* A catalog artifact's reader for the link's later block reads: the same authenticated cache read, plus the failure
 * notice naming THIS tensor when a block differs (a corrupt same-size file must be retired, not answered 'H' forever). */
struct sh_encoded_reader_ctx { sh_weight_cache *cache; std::string name; };
static int sh_encoded_reader(void *ctx, uint64_t offset, uint8_t *out, size_t bytes) {
    sh_encoded_reader_ctx *r = static_cast<sh_encoded_reader_ctx *>(ctx);
    const int rc = r->cache->read(offset, out, bytes);
    if (rc != 0) sh_encoded_failed(r->name, "block differs from the catalog at a later read");
    return rc;
}
#include "shielded-weight-source.h"
#include "shielded-source-prefetch.h"

/* --------------------------------------------------------------------------
 * Placement policy.
 *
 * Offload is a round trip, and a round trip has a floor cost that no amount of
 * GPU speed lowers. Two consequences, both tunable, neither per-request:
 *
 *  SHIELDED_MIN_MACS  A matmul below this many multiply-adds is cheaper to do
 *                     on the CPU inside the enclave than to ship. Qwen2.5-0.5B's
 *                     q/k/v/o projections (0.1-0.8 MMAC) sit under the default;
 *                     its FFN and lm_head (4.4-136 MMAC) sit above it.
 *  SHIELDED_MAX_M     Batches wider than this stay in the enclave. Refill costs
 *                     the TEE three residue planes of work per offloaded MAC,
 *                     so a prefill-sized batch is strictly cheaper computed in
 *                     the clear, in the enclave, once. Offload is a DECODE
 *                     accelerator: it removes the weight-bandwidth term from the
 *                     latency chain, and that is the only term it can remove.
 * ----------------------------------------------------------------------- */
static int64_t sh_min_macs() { static int64_t v = -1; if (v < 0) v = sh_env_int("SHIELDED_MIN_MACS", 2000000); return v; }
static int     sh_max_m()    { static int v = -1;     if (v < 0) v = sh_env_int("SHIELDED_MAX_M", 8); return v; }

/* --------------------------------------------------------------------------
 * Calibration.
 *
 * Two public, offline constants per site: the activation exponent and the
 * outlier channel set. Both are properties of the PUBLIC weights, calibrated on
 * public text and shipped like an imatrix, so neither leaks anything about a
 * request -- and both must be per-model constants rather than adapted to the
 * activation in hand, since an adaptive exponent would leak activation
 * magnitude. A site with no calibration is not offloaded at all: supports_op
 * says no and ggml_backend_sched quietly runs it on the CPU, in the enclave.
 * ----------------------------------------------------------------------- */
struct sh_calib_site {
    int act_frac = 0;
    std::vector<int64_t> outliers;
};


struct sh_state {
    std::mutex mu;
    std::string host = "127.0.0.1";
    int port = 9500, vsock_port = -1, refill_threads = -1;
    uint64_t reserve_bytes = 0;
    std::string shm_path;
    uint64_t shm_bytes = 0;
    bool explicit_link = false;
    std::string calib_path;
    bool configured = false;
    bool calib_loaded = false;
    /* "# shielded-calib N" on the file's first line. 1 = calibrate.py's
     * exponents, chosen against tee.py's per-TENSOR weight encoding, which
     * need the historical -5 against this backend's per-column products;
     * 2 = shielded-calib's, chosen against the very encoding this backend
     * applies. A file with no header is 1. The env delta is added on top. */
    int calib_version = 1;
    bool link_failed = false;
    // A failed opt-in cache build can leave half a shared-input group. Such
    // a table cannot consume the dealer's pads; abort before upload/binding.
    bool weight_cache_failed = false;
    bool source_verification_failed = false;
    /* Reconnect policy after a transport failure: the link is retried at the
     * next graph once `link_retry_at` has passed, with the wait doubling from
     * 1 s to 60 s. Until then every claimed matmul is computed in the enclave,
     * exactly and slowly. Before this the first socket error was PERMANENT:
     * a worker restart on the host left the tenant on the int64 path (6 tok/s
     * on the 0.5B) until the tenant itself was restarted. */
    double link_retry_at = 0, link_backoff_ms = 1000;
    std::map<std::string, sh_calib_site> calib;

    /* Reservation-aware placement. SHIELDED_RESERVE_BYTES is this tenant's slice
     * of the card (its GPU share x the card budget) - the same figure the worker
     * caps the link's device memory at. We place calibrated weights until that
     * budget is full and leave the rest on CPU, so a model LARGER than the card
     * offloads its first reservation-worth of sites cleanly. Without it the
     * backend kept handing weights to the worker past its budget, the worker
     * answered "allocation exceeds device memory" with a VIOLATION that CLOSES
     * the link, and the tenant lost ALL offload and reconnected into a thrash
     * loop. 0 = no reservation (a 4-byte HELLO): uncapped, exactly as before. */
    int64_t reserve_cap = 0;         /* device-byte budget for offloaded weights, 0 = uncapped */
    int64_t device_bytes = 0;        /* weight+activation device bytes we have placed */
    bool    budget_full_logged = false;

    sh_link *link = nullptr;
    /* Weight tensor name -> everything needed to run and to check it. Map nodes
     * never move, so the link may borrow `w` for its lifetime. */
    struct entry {
        int node = -1;
        /* Column-split placement (SHIELDED_SPLIT_COLS): this card's link holds
         * the output columns [col0, col0 + ncols) of the weight; N stays the
         * FULL width, because the caller's y row and this entry's descale and
         * outlier tables are full-width. ncols == 0 means the whole weight,
         * which is the ordinary single-owner placement. On the PRIMARY card's
         * entry the part_* vectors name every card's slice of this weight. */
        int64_t col0 = 0, ncols = 0;
        std::vector<int> part_cards, part_nodes;
        std::vector<int64_t> part_col0;
        std::string name;
        std::vector<int> f_w;           /* one exponent per output column */
        int64_t K = 0, N = 0;
        const sh_calib_site *site = nullptr;
        std::string group;
        std::vector<int8_t> w;          /* (N,K): THE encoding, borrowed by the link */
#ifdef SHIELDED_COMPACT
        std::unique_ptr<sh_compact_store, decltype(&sh_compact_free)> compact{nullptr, sh_compact_free};
#endif
        std::unique_ptr<sh_weight_cache> w_cache; /* opt-in, authenticated public blocks on disk */
        bool source_verified = false;
        bool encoded_hit = false;       /* w_cache is a catalog artifact (its later reads report a failed block by name) */
        std::unique_ptr<sh_encoded_reader_ctx> w_cache_ctx;
        std::vector<int8_t> out_cols;   /* nout x N: the outlier channels' weights, for the TEE-side term */
        std::vector<float> inv;         /* per-column descale 2^-(af + f_w[j]) */
        float act_scale = 0, encode_limit = 0;
    };
    // Borrow ggml's tensor names for lookup; the map still owns every key.
    // Long tensor names otherwise allocate a temporary string on each find.
    std::map<std::string, entry, std::less<>> weights;
    std::map<std::string, int> group_first;   /* group key -> first node in it */
    /* Every registered weight of each group, in registration order.
     *
     * ggml_backend_sched cuts the graph wherever the backend changes, and a
     * CPU op between two members of a group -- Qwen3's q_norm between attn_q
     * and attn_k -- puts them in different splits, so graph_compute sees the
     * group one member at a time. Exchanged naively that is one round trip and
     * one pad PER MEMBER for the same activation (Qwen3-4B: 181 exchanges per
     * token instead of 145). Instead, an exchange for a partial group asks the
     * worker for the WHOLE group's products and keeps the invisible members'
     * results here; the later split is served from that cache when its
     * activation is byte-identical to the one exchanged. One plaintext, one
     * pad, one round trip -- rule 2 held by construction across splits too.
     * Nothing new crosses the wire: the extra products are functions of the
     * same masked planes and the public weights, verified like every other. */
    std::map<std::string, std::vector<std::string>> group_members;
    struct gcache { int32_t m = 0; std::vector<int64_t> x; std::map<std::string, std::vector<int64_t>> y; };
    std::map<std::string, gcache> completion;
    std::vector<entry *> xents;               /* the exchange set of the current node */
    uint64_t completed = 0, served = 0;       /* group completions issued / members served from one */

    // Compare wire timings only within the same group AND batch width.
    // Keep one probe group offloaded during fallback to notice recovery.
    sh_contention contention;
    std::string probe_group;
    uint64_t contended_graphs = 0;
    std::set<std::string> refused;            /* names that failed registration, said once */
    bool dirty = false;                       /* new weights since the last start() */

    uint64_t offloaded_nodes = 0, local_nodes = 0, macs = 0, verify_fail = 0, exchanges = 0;
    /* Width diagnostics for the profile line: how many exchanges carried m
     * rows (m_hist[m], 9+ folded into [9]) and how many graphs reached this
     * backend whose widest claimed matmul had 1, 2-4, 5-8 or 9+ rows. The
     * question they answer: does a prompt reach us as wide graphs the sched
     * left on the CPU, or as narrow graphs (someone upstream sliced it)? */
    uint64_t m_hist[10] = {0}, graph_w[4] = {0};
    double t_encode = 0, t_link = 0, t_post = 0, t_graph = 0;
    /* Inside t_link, which the phase counters do not cover: the primary
     * card's own exchange, its slice post, and the wait for the other
     * cards' workers. Without these the split's share of a pass is a
     * subtraction, and a subtraction is what sent me after the wrong
     * millisecond once already. */
    double t_split_gemm = 0, t_split_post = 0, t_split_join = 0;
    uint64_t local_island_ops = 0;
    uint64_t idle_islands = 0;      /* islands computed inside an exchange window */
    uint64_t graph_calls = 0;
    int card_index = -1;
    /* Why the selector said no. "No islands were eligible" is a claim about
     * the graph; without these it is indistinguishable from a selector that
     * rejects everything for a reason of its own. */
    uint64_t sel_pattern = 0, sel_notready = 0, sel_inflight = 0, sel_alias = 0, sel_taken = 0;
    double t_local_island = 0;
    std::vector<float> local_inv_rms;

    /* graph_compute scratch, kept across calls: resize() never shrinks a
     * vector's capacity, so after the first token these are plain pointer
     * arithmetic. Bounded by max_m x Kmax (x) and max_m x sum N of the widest
     * group (y) -- for the 0.5B that is 8 x 151936 int64 = 9.7 MB at most.
     * Before this every exchange constructed and destroyed x_gpu, x_tee, one
     * vector per member and the bookkeeping vectors around them. */
    std::vector<int64_t> x_gpu, x_tee, ys;
    std::vector<int64_t *> yp;
    std::vector<int> nodes;
    std::vector<char> done;
    std::vector<ggml_tensor *> members;
    std::vector<entry *> ents;

    /* The link borrows `weights[*].w` for its lifetime and its refill threads
     * read them from the background. Static destruction order would free the
     * map first and let a thread mid-refill read freed memory (a real segfault
     * at process exit, seen on bench-batch); close the link -- which joins the
     * threads -- before any member goes. */
    ~sh_state() { if (link) { sh_link_close(link); link = nullptr; } }
};

static sh_state &sh_get() { static sh_state s; return s; }

/* One ACCEL facade, independent verified links. Only public weight metadata
 * drives placement. Nonlinear operations, KV, pads and verification stay in the
 * enclave; activations are never copied in the clear between host GPUs. */
struct sh_pool {
    std::mutex mu;
    bool initialized = false, invalid = false;
    size_t backend_refs = 0;
    ggml_shielded_cpu_idle_hook cpu_idle_hook = nullptr;
    void *cpu_idle_ctx = nullptr;
    std::vector<std::unique_ptr<sh_state>> extra;
    std::vector<sh_state *> cards;
    std::map<std::string, ggml_tensor> pending;
    std::vector<struct sh_split_worker *> split_workers;   /* one per non-primary card; process-lifetime */
    std::map<std::string, int> owners;       // activation group -> card, -1 = CPU
    std::map<std::string, int> layers;
};
static sh_pool &sh_pool_get() { static sh_pool p; return p; }
static void sh_split_report();   /* defined after sh_split_worker */
static double sh_split_helper_gemm();
static double sh_split_helper_post();
static void sh_pool_init(sh_pool &p);
void ggml_backend_shielded_set_cpu_idle_hook(ggml_shielded_cpu_idle_hook hook, void *ctx) {
    sh_pool &p = sh_pool_get();
    std::lock_guard<std::mutex> lock(p.mu);
    p.cpu_idle_hook = hook; p.cpu_idle_ctx = hook ? ctx : nullptr;
}
static int sh_owner(sh_pool &p, const ggml_tensor *w) {
    auto it = p.owners.find(sh_group_key(ggml_get_name(w)));
    return it == p.owners.end() ? -1 : it->second;
}
static void sh_plan(sh_pool &p);
static bool sh_split_cols();

int ggml_backend_shielded_set_weight_verifier(ggml_shielded_weight_verifier verifier, void *ctx) {
    sh_pool &p = sh_pool_get();
    std::lock_guard<std::mutex> lk(p.mu);
    sh_pool_init(p);
    if (!verifier || g_weight_verifier || p.invalid || !p.pending.empty()) return SH_ERR_RANGE;
    for (const auto *s : p.cards)
        if (!s->weights.empty() || !s->refused.empty() || s->source_verification_failed || s->weight_cache_failed)
            return SH_ERR_RANGE;
    g_weight_verifier = verifier; g_weight_verifier_ctx = ctx;
    return SH_OK;
}

int ggml_backend_shielded_set_source_release(ggml_shielded_source_release release, void *ctx) {
    sh_pool &p = sh_pool_get();
    std::lock_guard<std::mutex> lk(p.mu);
    if (!release || g_source_release || !g_weight_verifier || p.invalid || !p.pending.empty()) return SH_ERR_RANGE;
    for (const auto *s : p.cards)
        if (!s->weights.empty() || !s->refused.empty() || s->source_verification_failed || s->weight_cache_failed)
            return SH_ERR_RANGE;
    g_source_release = release; g_source_release_ctx = ctx;
    return SH_OK;
}

static void sh_release_consumed_sources(sh_pool &p) {
    if (!g_source_release) return;
    int rc = SH_ERR_IO;
    try { rc = g_source_release(g_source_release_ctx); } catch (...) { }
    if (rc != SH_OK) {
        for (auto *s : p.cards) s->source_verification_failed = true;
        fprintf(stderr, "[shielded] consumed source retirement failed; aborting model load\n");
    }
}

/* Same admission rules as the verifier: only before any registration, and only WITH a verifier (the catalog is an
 * authority over public bytes; unverified runs keep their source path). */
int ggml_backend_shielded_set_encoded_source(ggml_shielded_encoded_source source, void *ctx) {
    sh_pool &p = sh_pool_get();
    std::lock_guard<std::mutex> lk(p.mu);
    sh_pool_init(p);
    if (!source || g_encoded_source || !g_weight_verifier || p.invalid || !p.pending.empty()) return SH_ERR_RANGE;
    for (const auto *s : p.cards)
        if (!s->weights.empty() || !s->refused.empty() || s->source_verification_failed || s->weight_cache_failed)
            return SH_ERR_RANGE;
    g_encoded_source = source; g_encoded_source_ctx = ctx;
    return SH_OK;
}
/* Same admission, and only once a source is installed: a failure notice can only ever name an artifact the source served. */
int ggml_backend_shielded_set_encoded_failure(ggml_shielded_encoded_failure notify, void *ctx) {
    sh_pool &p = sh_pool_get();
    std::lock_guard<std::mutex> lk(p.mu);
    sh_pool_init(p);
    if (!notify || g_encoded_failure || !g_encoded_source || p.invalid || !p.pending.empty()) return SH_ERR_RANGE;
    for (const auto *s : p.cards)
        if (!s->weights.empty() || !s->refused.empty() || s->source_verification_failed || s->weight_cache_failed)
            return SH_ERR_RANGE;
    g_encoded_failure = notify; g_encoded_failure_ctx = ctx;
    return SH_OK;
}

/* The correction every site's calibrated exponent gets: the file format's own
 * (see calib_version) plus the process-wide SHIELDED_AF_DELTA. */
static int64_t sh_af_delta(const sh_state &s) { return (s.calib_version == 1 ? INT64_C(-5) : 0) + sh_af_delta_env(); }

void ggml_backend_shielded_configure(const char *host, int port, const char *calib_path) {
    sh_state &s = sh_get();
    std::lock_guard<std::mutex> lk(s.mu);
    if (host && *host) s.host = host;
    if (port > 0) s.port = port;
    if (calib_path && *calib_path) { s.calib_path = calib_path; s.calib_loaded = false; }
    s.configured = true;
}

int ggml_backend_shielded_pool_version(void) { return 1; }

/* Single-card paired experiment, selected outside decode. The same locks as
 * graph execution prevent socket-option changes during an exchange. Refuse a
 * pool rather than partially applying the experiment to several cards. */
extern "C" int ggml_backend_shielded_set_rcvlowat(int cap, uint64_t *buffer_bytes) {
    sh_pool &p = sh_pool_get();
    std::lock_guard<std::mutex> lock(p.mu);
    if (p.cards.size() != 1) return SH_ERR_RANGE;
    sh_state &s = *p.cards[0];
    std::lock_guard<std::mutex> state_lock(s.mu);
    return sh_link_set_rcvlowat(s.link, cap, buffer_bytes);
}
extern "C" int ggml_backend_shielded_set_rcvbuf(int bytes, uint64_t *actual_bytes) {
    sh_pool &p = sh_pool_get();
    std::lock_guard<std::mutex> lock(p.mu);
    if (p.cards.size() != 1) return SH_ERR_RANGE;
    sh_state &s = *p.cards[0];
    std::lock_guard<std::mutex> state_lock(s.mu);
    return sh_link_set_rcvbuf(s.link, bytes, actual_bytes);
}

/* Pad-budget diagnostic. Same lock ORDER as every other exported query,
 * sh_pool::mu then sh_state::mu, but TRY-locked at both levels: graph_compute
 * holds p.mu for a whole graph and sh_card_compute holds s.mu across a link
 * start, so a diagnostic that waited would stall decode rather than observe it.
 * A failed try-lock is SH_PAD_BUDGET_BUSY, which means NOT OBSERVED and must
 * never be read as an empty bank.
 *
 * It deliberately does NOT call sh_pool_init: asking for a diagnostic must
 * never bring a backend up. Holding sh_state::mu is what makes this link's
 * reader, group array and request counters safe to read, because
 * sh_card_compute holds the same mutex around sh_link_start (the only caller of
 * start_pools) and around the gemm that writes pads_used without pool_mu; that
 * is why the flag below is passed. Nothing is formatted here: the caller owns
 * the arrays and prints after this returns with every lock dropped.
 *
 * Decode does not proceed on other cards meanwhile - graph_compute needs the
 * same p.mu - but each card's refill threads resume as soon as its pool_mu is
 * released, so reading several cards is a sequence of observations rather than
 * one atomic inventory. */
static void sh_pad_budget_unavailable(sh_pad_budget *out, int card, int status,
                                      uint32_t cap_intervals, uint32_t cap_groups) {
    memset(out, 0, sizeof *out);
    out->version = SH_PAD_BUDGET_VERSION;
    out->card = card;
    out->status = out->reader_status = status;
    out->cap_intervals = cap_intervals;
    out->cap_groups = cap_groups;
}

extern "C" int ggml_backend_shielded_pad_budget_cards(void) {
    sh_pool &p = sh_pool_get();
    std::unique_lock<std::mutex> lock(p.mu, std::try_to_lock);
    if (!lock.owns_lock()) return -SH_PAD_BUDGET_BUSY;   /* negative: busy, not "no cards" */
    if (!p.initialized) return 0;
    return (int)p.cards.size();
}

extern "C" int ggml_backend_shielded_pad_budget(int card, sh_pad_budget *out,
                                                sh_pad_interval *intervals, uint32_t cap_intervals,
                                                sh_pad_group_budget *groups, uint32_t cap_groups) {
    if (!out) return SH_PAD_BUDGET_UNAVAILABLE;
    sh_pool &p = sh_pool_get();
    std::unique_lock<std::mutex> lock(p.mu, std::try_to_lock);
    if (!lock.owns_lock()) {
        sh_pad_budget_unavailable(out, card, SH_PAD_BUDGET_BUSY, cap_intervals, cap_groups);
        return SH_PAD_BUDGET_BUSY;
    }
    if (!p.initialized || card < 0 || (size_t)card >= p.cards.size()) {
        sh_pad_budget_unavailable(out, card, SH_PAD_BUDGET_UNAVAILABLE, cap_intervals, cap_groups);
        return SH_PAD_BUDGET_UNAVAILABLE;
    }
    sh_state &s = *p.cards[card];
    std::unique_lock<std::mutex> state_lock(s.mu, std::try_to_lock);
    if (!state_lock.owns_lock()) {
        sh_pad_budget_unavailable(out, card, SH_PAD_BUDGET_BUSY, cap_intervals, cap_groups);
        return SH_PAD_BUDGET_BUSY;
    }
    const int rc = sh_link_pad_budget(s.link, out, SH_PAD_BUDGET_F_REQUEST_PATH_EXCLUDED,
                                      intervals, cap_intervals, groups, cap_groups);
    out->card = card;
    return rc;
}

void ggml_backend_shielded_weight_cache_stats(uint64_t *calls, uint64_t *bytes) {
    sh_pool &p = sh_pool_get();
    std::lock_guard<std::mutex> lock(p.mu);
    uint64_t c = 0, b = 0;
    for (auto *s : p.cards) {
        std::lock_guard<std::mutex> state_lock(s->mu);
        for (const auto &entry : s->weights) if (entry.second.w_cache) {
            c += entry.second.w_cache->read_calls(); b += entry.second.w_cache->read_bytes();
        }
    }
    if (calls) *calls = c;
    if (bytes) *bytes = b;
}
void ggml_backend_shielded_pads_used(uint64_t *used, uint64_t *missed) {
    sh_pool &p = sh_pool_get();
    std::lock_guard<std::mutex> lock(p.mu);
    uint64_t u = 0, m = 0;
    for (size_t card = 0; card < p.cards.size(); card++) {
        sh_state &s = *p.cards[card];
        std::lock_guard<std::mutex> lk(s.mu);
        uint64_t cu = 0, cm = 0;
        if (s.link) sh_link_pool_stats(s.link, &cu, &cm);
        u += cu; m += cm;
    }
    if (used) *used = u;
    if (missed) *missed = m;
}

int ggml_backend_shielded_profile_snapshot(uint64_t *out, size_t count) {
    // v1: version, cards, exchanges, offloaded nodes, local nodes;
    // cumulative microseconds: encode, link, post, graph, split gemm/post/join,
    // mask, wire, refill-on-path, unmask-lhs, rhs, check, pads, idle, pad-wait;
    // then pads used, missed, waited. Card times overlap; do not sum as wall time.
    if (!out || count < 24) return -1;
    // SHIELDED_PROFILE_LAYOUT=pads, which the guest init sets beside the pad
    // spill: the pad bank and nothing else, for the app's page to show. v[0]
    // stays 1, the only version the runtime's header passes on; v[1] is
    // 0x50414442 ("PADB") where v1 has the card count. It comes from the
    // links' own counters (sh_spill_gauge_read), so a running graph neither
    // delays nor refuses it.
    //   2 layout (1), 3 links, 4 links with a spill, 5 pads it has room for,
    //   6 pads ready, 7 prompt tokens it has room for, 8 prompt tokens ready,
    //   9 pads written, 10 imported by refills, 11 imported on the request
    //   path, 12 failures, 13 threads minting into it now, 14 ms since a
    //   request took pads, 15 the idle threshold in ms, 16 bytes one prompt
    //   token's pads take, 17 bank bytes.
    if (const char *layout = getenv("SHIELDED_PROFILE_LAYOUT"); layout && !strcmp(layout, "pads")) {
        sh_spill_gauge g; sh_spill_gauge_read(&g);
        const uint64_t v[24] = {1, 0x50414442, 1, g.links, g.attached, g.capacity, g.ready,
            g.rows_cap, g.rows, g.written, g.imported, g.onpath, g.failed, g.minters,
            g.quiet_ms, g.idle_ms, g.row_bytes, g.bytes};
        std::copy(v, v + 24, out);
        return 1;
    }
    sh_pool &p = sh_pool_get();
    std::unique_lock<std::mutex> lock(p.mu, std::try_to_lock);
    if (!lock.owns_lock()) return 0;
    std::vector<std::unique_lock<std::mutex>> cards;
    for (auto *s : p.cards) {
        cards.emplace_back(s->mu, std::try_to_lock);
        if (!cards.back().owns_lock()) return 0;
    }
    uint64_t v[24] = {1, (uint64_t)p.cards.size()};
    for (auto *s : p.cards) {
        sh_link_profile lp{}; sh_link_profile_snapshot(s->link, &lp);
        uint64_t used=0, missed=0, waited=0; double wait_ms=0;
        sh_link_pool_stats(s->link, &used, &missed);
        sh_link_pad_wait_stats(s->link, &waited, &wait_ms);
        v[2] += s->exchanges; v[3] += s->offloaded_nodes; v[4] += s->local_nodes;
        const double ms[] = {s->t_encode,s->t_link,s->t_post,s->t_graph,
            s->t_split_gemm,s->t_split_post,s->t_split_join,lp.mask_ms,lp.wire_ms,
            lp.refill_ms,lp.unmask_lhs_ms,lp.rhs_ms,lp.check_ms,lp.pads_ms,lp.idle_ms,wait_ms};
        for (size_t i=0; i<16; ++i) v[5+i] += (uint64_t)(std::max(0.0,ms[i])*1000.0);
        v[21] += used; v[22] += missed; v[23] += waited;
    }
    std::copy(v,v+24,out);
    return 1;
}

void ggml_backend_shielded_stats(uint64_t *off, uint64_t *loc, uint64_t *macs, uint64_t *vf) {
    sh_pool &p = sh_pool_get();
    std::lock_guard<std::mutex> lock(p.mu);
    sh_pool_init(p);
    if (off) *off = 0;
    if (loc) *loc = 0;
    if (macs) *macs = 0;
    if (vf) *vf = 0;
    for (size_t card = 0; card < p.cards.size(); card++) {
    sh_state &s = *p.cards[card];
    std::lock_guard<std::mutex> lk(s.mu);
    if (getenv("SHIELDED_PROFILE")) {
        fprintf(stderr, "[shielded] card %zu %s:%d device_bytes=%lld reserve_cap=%lld\n",
                card, s.host.c_str(), s.port, (long long)s.device_bytes, (long long)s.reserve_cap);
        uint64_t used = 0, missed = 0;
        if (s.link) sh_link_pool_stats(s.link, &used, &missed);
        uint64_t waited = 0; double wait_ms = 0;
        sh_link_pad_wait_stats(s.link, &waited, &wait_ms);
        sh_wire_timing wt = {}; sh_link_wire_timing(s.link, &wt);
        sh_link_profile lp = {}; sh_link_profile_snapshot(s.link, &lp);
        fprintf(stderr, "[shielded] wire phases: calls=%llu request_bytes=%llu reply_bytes=%llu write=%.1fms overlap=%.1fms header=%.1fms body=%.1fms max=%.1fms over100ms=%llu over1s=%llu (socket FIELD_GEMM only; body includes allocation)\n",
                (unsigned long long)wt.calls, (unsigned long long)wt.request_bytes, (unsigned long long)wt.reply_bytes,
                wt.write_ms, wt.work_ms, wt.header_ms, wt.body_ms, wt.max_ms,
                (unsigned long long)wt.over_100ms, (unsigned long long)wt.over_1s);
        if (wt.peak.call) fprintf(stderr, "[shielded] wire slowest: call=%llu cmd=%u metadata=%u first_node=%u name=%s nodes=%u m=%u K=%llu request_bytes=%llu reply_bytes=%llu write=%.1fms overlap=%.1fms header=%.1fms body=%.1fms total=%.1fms (cumulative successful socket calls, not a round)\n",
                (unsigned long long)wt.peak.call, wt.peak.cmd, wt.peak.metadata_valid, wt.peak.first_node,
                wt.peak.first_node_name[0] ? wt.peak.first_node_name : "unknown", wt.peak.nodes, wt.peak.rows,
                (unsigned long long)wt.peak.K, (unsigned long long)wt.peak.request_bytes, (unsigned long long)wt.peak.reply_bytes,
                wt.peak.write_ms, wt.peak.work_ms, wt.peak.header_ms, wt.peak.body_ms, wt.max_ms);
        sh_split_report();
        fprintf(stderr, "[shielded] widths: exchanges by rows m1=%llu m2=%llu m3=%llu m4=%llu m5=%llu m6=%llu m7=%llu m8=%llu m9+=%llu | graphs by widest matmul rows 1=%llu 2-4=%llu 5-8=%llu 9+=%llu\n",
                (unsigned long long)s.m_hist[1], (unsigned long long)s.m_hist[2], (unsigned long long)s.m_hist[3], (unsigned long long)s.m_hist[4], (unsigned long long)s.m_hist[5], (unsigned long long)s.m_hist[6], (unsigned long long)s.m_hist[7], (unsigned long long)s.m_hist[8], (unsigned long long)s.m_hist[9],
                (unsigned long long)s.graph_w[0], (unsigned long long)s.graph_w[1], (unsigned long long)s.graph_w[2], (unsigned long long)s.graph_w[3]);
        if (sh_link_has_bank(s.link)) {
            uint64_t bf = 0, bb = 0; int bst = 0; char berr[256];
            sh_link_bank_stats(s.link, &bf, &bb, &bst, berr, sizeof berr);
            fprintf(stderr, "[shielded] bank: fetched %llu shipment(s) %.0f MB, last listing http %d%s%s\n",
                    (unsigned long long)bf, bb / 1e6, bst, berr[0] ? "; " : "", berr);
        }
        fprintf(stderr, "[shielded] profile: exchanges=%llu nodes=%llu (completions=%llu served=%llu) | link: mask=%.1fms wire=%.1fms "
                        "refill-on-path=%.1fms unmask+lhs=%.1fms rhs=%.1fms check=%.1fms pads=%.1fms idle=%.1fms/%lluex total=%.1fms | backend: encode=%.1fms "
                        "post=%.1fms graph_compute=%.1fms | split: gemm=%.1fms post=%.1fms join=%.1fms | pads used=%llu missed=%llu waited=%llu wait=%.1fms | contended=%d events=%llu | simd=%s refill_threads=%d refill_priority=%s omp_spincount=%s\n",
                (unsigned long long)s.exchanges, (unsigned long long)s.offloaded_nodes,
                (unsigned long long)s.completed, (unsigned long long)s.served,
                lp.mask_ms, lp.wire_ms, lp.refill_ms, lp.unmask_lhs_ms, lp.rhs_ms,
                lp.check_ms, lp.pads_ms, lp.idle_ms, (unsigned long long)lp.idle_n, s.t_link,
                s.t_encode, s.t_post, s.t_graph, s.t_split_gemm, s.t_split_post, s.t_split_join,
                (unsigned long long)used, (unsigned long long)missed,
                (unsigned long long)waited, wait_ms,
                (int)s.contention.contended, (unsigned long long)s.contention.events,
                sh_link_simd()->name, s.link ? sh_link_refill_threads(s.link) : 0,
                sh_link_refill_priority(s.link), getenv("GOMP_SPINCOUNT") ? getenv("GOMP_SPINCOUNT") : "default");
        if (s.local_island_ops)
            fprintf(stderr, "[shielded] local residual/norm islands: ops=%llu time=%.1fms (no product-weight fusion)\n",
                    (unsigned long long)s.local_island_ops, s.t_local_island);
        if (s.sel_pattern)
            fprintf(stderr, "[shielded] overlap selector: pattern=%llu taken=%llu rejected: in-flight=%llu not-ready=%llu alias=%llu\n",
                    (unsigned long long)s.sel_pattern, (unsigned long long)s.sel_taken,
                    (unsigned long long)s.sel_inflight, (unsigned long long)s.sel_notready,
                    (unsigned long long)s.sel_alias);
        if (s.idle_islands)
            fprintf(stderr, "[shielded] overlap pilot: %llu islands computed inside an exchange window\n",
                    (unsigned long long)s.idle_islands);
        // Identify the groups delaying GPU submission. Aggregate misses alone
        // cannot distinguish a large output head from an undersized whole pool.
        struct stalled_group { std::string name; uint64_t used, missed; double ms; };
        std::vector<stalled_group> stalls;
        for (const auto &group : s.group_members) {
            if (!s.link || group.second.empty()) continue;
            auto e = s.weights.find(group.second.front());
            if (e == s.weights.end()) continue;
            stalled_group g{group.first, 0, 0, 0};
            sh_link_node_pool_stats(s.link, e->second.node, &g.used, &g.missed, &g.ms);
            if (g.missed) stalls.push_back(std::move(g));
        }
        std::sort(stalls.begin(), stalls.end(), [](const stalled_group &a, const stalled_group &b) {
            return a.ms > b.ms;
        });
        for (size_t i = 0; i < std::min<size_t>(3, stalls.size()); i++) {
            const auto &g = stalls[i];
            fprintf(stderr, "[shielded] profile: card=%zu group=%s pads=%llu missed=%llu on-path=%.1fms local_nodes=%llu\n",
                    card, g.name.c_str(), (unsigned long long)g.used, (unsigned long long)g.missed,
                    g.ms, (unsigned long long)s.local_nodes);
        }
    }
    if (off)  *off  += s.offloaded_nodes;
    if (loc)  *loc  += s.local_nodes;
    if (macs) *macs += s.macs;
    if (vf)   *vf   += s.verify_fail;
    }
    if (getenv("SHIELDED_PROFILE")) {
        using snapshot_fn = void (*)(uint64_t *);
        static auto snapshot = reinterpret_cast<snapshot_fn>(dlsym(RTLD_DEFAULT, "enclave_omp_profile_snapshot"));
        static auto snapshot_v2 = reinterpret_cast<snapshot_fn>(dlsym(RTLD_DEFAULT, "enclave_omp_profile_snapshot_v2"));
        if (snapshot) {
            uint64_t values[5] = {};
            (snapshot_v2 ? snapshot_v2 : snapshot)(values);
            if (values[0]) {
                fprintf(stderr, "[shielded] omp-profile: regions=%llu wall=%.3fms caller=%.3fms entry-exit=%.3fms",
                    (unsigned long long)values[0], values[1] / 1e6, values[2] / 1e6,
                    (values[1] - values[2]) / 1e6);
                if (snapshot_v2) fprintf(stderr, " caller-barriers=%llu caller-barrier=%.3fms",
                    (unsigned long long)values[3], values[4] / 1e6);
                fputc('\n', stderr);
            }
        }
    }
}

/* Read the environment once, so enabling the tier is launch configuration rather
 * than an app-visible API -- existing catalog guests keep their wasi-nn contract
 * unchanged, which is the point of putting the split here at all. An explicit
 * ggml_backend_shielded_configure() still wins. */
static void sh_env_defaults(sh_state &s) {
    if (s.configured) return;
    s.configured = true;
    if (const char *h = getenv("SHIELDED_HOST")) if (*h) s.host = h;
    if (const char *p = getenv("SHIELDED_PORT")) if (*p) { const int v = atoi(p); if (v > 0) s.port = v; }
    /* The card slice this tenant reserved (shielded-tee.c sends the same number
     * to the worker at HELLO). Keep headroom below it for the activation buffers
     * and field-GEMM scratch the worker also charges to the link - weights are
     * the dominant term but not the only one. SHIELDED_WEIGHT_BUDGET_FRAC tunes
     * the headroom; 0.90 leaves 10%. */
    if (const char *r = getenv("SHIELDED_RESERVE_BYTES")) {
        char *end = nullptr; unsigned long long v = strtoull(r, &end, 10);
        if (end && *end == 0 && v > 0) {
            const char *fe = getenv("SHIELDED_WEIGHT_BUDGET_FRAC");
            double frac = (fe && *fe) ? atof(fe) : 0.90;
            if (!(frac > 0.1 && frac <= 1.0)) frac = 0.90;
            s.reserve_cap = (int64_t)((double)v * frac);
        }
    }
}

/* Manager-generated records: host|tcp-port|vsock-port|reservation-bytes,
 * optionally followed by |card-bound-shm-path|shm-bytes.
 * one per line. Strict parsing is fail-closed: a malformed pool must never
 * turn a paid slice into the legacy uncapped single-worker connection. */
static void sh_pool_init(sh_pool &p) {
    if (p.initialized) return;
    p.initialized = true;
    p.cards.push_back(&sh_get());
    const char *env = getenv("SHIELDED_WORKERS");
    if (!env) return;
    /* Say WHY. A bare "invalid worker pool" sends the reader looking at their
     * config, the parser, the library build and the environment in turn; the
     * ring-path rule in particular rejects a perfectly well-formed line for a
     * reason that is a COMPILE-TIME decision and invisible from the string. */
    auto reject = [&](const char *why) {
        p.invalid = true;
        p.cards.resize(1);
        p.extra.clear();
        fprintf(stderr, "[shielded] invalid worker pool (%s); all operations stay on CPU\n", why);
    };
    if (!*env || strlen(env) > 8192) { reject("empty or over 8192 bytes"); return; }
    std::istringstream lines(env);
    std::string line;
    std::set<std::string> endpoints;
    std::set<std::string> shm_paths;
    std::vector<std::unique_ptr<sh_state>> parsed;
    while (std::getline(lines, line)) {
        std::vector<std::string> parts;
        std::istringstream fields(line);
        std::string part;
        while (std::getline(fields, part, '|')) parts.push_back(part);
        if ((parts.size() != 4 && parts.size() != 6) || parts[0].empty() || parts[0].size() > 127 || parsed.size() >= 16) {
            reject("line needs 4 or 6 fields with a valid host"); return;
        }
        const std::string broker_prefix = "unix:/run/enclave-shield/gpu";
        const bool local_broker = parts[0].compare(0, broker_prefix.size(), broker_prefix) == 0;
        if (local_broker) {
            const std::string id = parts[0].substr(broker_prefix.size());
            if (id.empty() || id.size() > 2 || id.find_first_not_of("0123456789") != std::string::npos ||
                (id.size() > 1 && id[0] == '0') || atoi(id.c_str()) >= 16) {
                reject("invalid private broker path"); return;
            }
        } else if (parts[0].find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._:-") != std::string::npos) {
            reject("invalid worker host"); return;
        }
        uint64_t nums[3];
        for (int i = 0; i < 3; i++) {
            if (parts[i+1].empty() || parts[i+1].find_first_not_of("0123456789") != std::string::npos || parts[i+1].size() > 15) { reject("port/vsock/reservation must be plain decimal"); return; }
            nums[i] = strtoull(parts[i+1].c_str(), nullptr, 10);
        }
        if (nums[0] < 1 || nums[0] > 65535 || nums[1] > (1U << 30) || nums[2] < 1 || nums[2] > (1ULL << 50) ||
            (local_broker && nums[1] != 0) ||
            !endpoints.insert(local_broker ? parts[0] : parts[0] + ":" + std::to_string(nums[0])).second) { reject("port out of range, reservation out of range, or duplicate endpoint"); return; }
        auto s = std::make_unique<sh_state>();
        sh_env_defaults(*s);
        if (parts.size() == 6) {
            /* The ring lives at ONE fixed, root-owned location in the CVM, so a
             * worker's config string can never point the trusted half at a
             * path it chose. A bench box has no such directory, so the harness
             * build (and only that build) also accepts the same layout under
             * /dev/shm -- which is world-writable, hence not a production
             * option even though the ring's contents are masked and checked. */
            std::string prefix = "/dev/enclave-shielded-shm/card-";
#ifdef SHIELDED_ALLOW_DEV_SHM_RINGS
            if (parts[4].compare(0, prefix.size(), prefix) != 0) prefix = "/dev/shm/enclave-shielded-shm/card-";
#endif
            if (parts[4].compare(0, prefix.size(), prefix) != 0) { reject("ring path outside the permitted directory -- a /dev/shm ring needs a build with SHIELDED_EXTRA_DEFS=-DSHIELDED_ALLOW_DEV_SHM_RINGS"); return; }
            const std::string id = parts[4].substr(prefix.size());
            if (id.empty() || id.size() > 2 || id.find_first_not_of("0123456789") != std::string::npos ||
                (id.size() > 1 && id[0] == '0') || atoi(id.c_str()) >= 16 ||
                !shm_paths.insert(parts[4]).second || parts[5].empty() || parts[5].size() > 8 ||
                parts[5].find_first_not_of("0123456789") != std::string::npos) { reject("ring card id or size field malformed"); return; }
            const uint64_t bytes = strtoull(parts[5].c_str(), nullptr, 10);
            if (bytes < 8 * 1048576ULL || bytes > 64 * 1048576ULL || (bytes & (bytes - 1))) { reject("ring size must be a power of two from 8 to 64 MiB"); return; }
            s->shm_path = parts[4]; s->shm_bytes = bytes;
        }
        s->host = parts[0]; s->port = (int)nums[0]; s->vsock_port = (int)nums[1];
        s->reserve_bytes = nums[2]; s->explicit_link = true;
        double frac = getenv("SHIELDED_WEIGHT_BUDGET_FRAC") ? atof(getenv("SHIELDED_WEIGHT_BUDGET_FRAC")) : .90;
        if (!(frac > .1 && frac <= 1)) frac = .90;
        s->reserve_cap = std::max<int64_t>(1, (int64_t)(nums[2] * frac));
        parsed.push_back(std::move(s));
    }
    if (parsed.empty()) { reject("no usable worker lines"); return; }
    for (size_t c = 0; c < parsed.size(); c++) parsed[c]->card_index = (int)c;
    // A single process-wide refill budget, divided over links. More cards must
    // not create N copies of the old ncores/2 thread pool.
    int threads = sh_env_int("SHIELDED_REFILL_THREADS", (int)std::max(1U, std::thread::hardware_concurrency()/2));
    threads = std::max(0, std::min(64, threads));
    p.cards.clear();
    for (size_t i = 0; i < parsed.size(); i++) {
        parsed[i]->refill_threads = threads / (int)parsed.size() + ((int)i < threads % (int)parsed.size());
        p.cards.push_back(parsed[i].get());
    }
    p.extra = std::move(parsed);
    SH_LOG("pool: %zu workers, %d total refill threads\n", p.cards.size(), threads);
}

static void sh_load_calib(sh_state &s) {
    if (s.calib_loaded) return;
    s.calib_loaded = true;
    if (s.calib_path.empty()) {
        const char *e = getenv("SHIELDED_CALIB");
        if (e && *e) s.calib_path = e;
    }
    if (s.calib_path.empty()) {
        SH_LOG("no calibration configured; nothing will be offloaded\n");
        return;
    }
    FILE *f = fopen(s.calib_path.c_str(), "r");
    if (!f) { SH_LOG("calibration %s unreadable; nothing will be offloaded\n", s.calib_path.c_str()); return; }
    char line[8192];
    bool first = true;
    while (fgets(line, sizeof line, f)) {
        if (first) { int v = 0; if (sscanf(line, "# shielded-calib %d", &v) == 1) s.calib_version = v; first = false; }
        if (line[0] == '#' || line[0] == '\n') continue;
        char name[512]; int af = 0, nout = 0; int pos = 0;
        if (sscanf(line, "site %511s %d %d%n", name, &af, &nout, &pos) < 3) continue;
        sh_calib_site site;
        site.act_frac = af;
        const char *p = line + pos;
        for (int i = 0; i < nout; i++) {
            long long v = 0; int adv = 0;
            if (sscanf(p, " %lld%n", &v, &adv) != 1) break;
            site.outliers.push_back((int64_t)v);
            p += adv;
        }
        s.calib[name] = std::move(site);
    }
    fclose(f);
    if (s.calib_version != 1 && s.calib_version != 2) {
        fprintf(stderr, "[shielded] %s: calibration format %d is unknown; nothing will be offloaded\n", s.calib_path.c_str(), s.calib_version);
        s.calib.clear();
    }
    SH_LOG("calibration: %zu sites from %s, format %d%s (policy: min %lld MAC, max m %d, simd %s)\n",
           s.calib.size(), s.calib_path.c_str(), s.calib_version,
           s.calib_version == 1 ? " (calibrate.py exponents: applying the -5 per-column correction)" : "",
           (long long)sh_min_macs(), sh_max_m(), sh_link_simd()->name);
}

/* SHIELDED_LOCAL_SITES=name[,name...]: calibrated sites the backend still does NOT
 * claim, so they compute locally on the CPU backend. Inert unless set. Why: on the
 * phone anchor the vocab projection (token_embd.weight, tied) is one exchange per
 * row with a 456 KB reply; at the USB link's rate that costs more than the phone's
 * own dotprod cores do (~4 ms per row), and every MTP draft step is such a row. */
static bool sh_site_forced_local(const char *name) {
    static std::set<std::string> local; static bool parsed = false;
    if (!parsed) {
        parsed = true;
        if (const char *e = getenv("SHIELDED_LOCAL_SITES")) {
            std::string v = e; size_t at = 0;
            while (at <= v.size()) { size_t c = v.find(',', at); if (c == std::string::npos) c = v.size();
                if (c > at) local.insert(v.substr(at, c - at)); at = c + 1; }
        }
    }
    return !local.empty() && (local.count(name) || local.count(sh_group_key(name)));
}
static const sh_calib_site *sh_site_for(sh_state &s, const char *name) {
    sh_env_defaults(s);
    sh_load_calib(s);
    if (sh_site_forced_local(name)) return nullptr;
    auto it = s.calib.find(sh_group_key(name));
    return it == s.calib.end() ? nullptr : &it->second;
}

bool ggml_backend_shielded_source_candidate(const ggml_tensor *w) {
    if (!w || w->view_src || !ggml_is_contiguous(w) || w->ne[2] != 1 || w->ne[3] != 1 ||
        w->ne[0] <= 0 || w->ne[1] <= 0 || !sh_source_type_ok(w->type) ||
        !sh_source_geometry_ok(w->type, w->ne[0]) || w->ne[0] % SH_QK ||
        !sh_layout_fits(w->ne[0], w->ne[1], sh_max_m()) ||
        w->ne[0] * w->ne[1] < sh_min_macs()) return false;
    // Never make a token-indexed embedding lookup an observable storage read.
    const char *name = ggml_get_name(w);
    if (strncmp(name, "blk.", 4) || strstr(name, "token_embd")) return false;
    sh_pool &p = sh_pool_get();
    std::lock_guard<std::mutex> lk(p.mu);
    sh_pool_init(p);
    return !p.invalid && sh_site_for(*p.cards[0], name);
}

/* --------------------------------------------------------------------------
 * Weight registration: from ggml's rows into THE encoding, one row per output,
 * which is also what the worker wants. No transpose anywhere. A q8_0 source
 * goes straight in; any other quantization converts a row at a time on the way
 * (shielded-source-quant.h), which is why the type travels with the pointer.
 * ----------------------------------------------------------------------- */
static int sh_prepare_rows_threaded(const void *blocks, ggml_type type, int64_t K, int64_t N, int8_t *w_out, int *f_out) {
    const bool convert = type != GGML_TYPE_Q8_0;
    unsigned hw = std::thread::hardware_concurrency();
    int nt = (int)std::min<unsigned>(hw ? hw : 1, 16);
    if (N < 256 || (int64_t)nt * 16 > N) nt = 1;
    if (nt == 1)
        return convert ? sh_prepare_rows_any(blocks, type, K, N, 0, N, w_out, f_out)
                       : sh_prepare_weight_rows(blocks, K, N, w_out, f_out);
    std::vector<int> rc((size_t)nt, 0);
    std::vector<std::thread> th;
    for (int t = 0; t < nt; t++)
        th.emplace_back([&, t]() {
            const int64_t j0 = N * t / nt, j1 = N * (t + 1) / nt;
            rc[t] = convert ? sh_prepare_rows_any(blocks, type, K, N, j0, j1, w_out, f_out)
                            : sh_prepare_weight_rows_range(blocks, K, N, j0, j1, w_out, f_out);
        });
    for (auto &x : th) x.join();
    for (int r : rc) if (r < 0) return r;
    return 0;
}

/* In required-public-cache mode, registration still authenticates/encodes W
 * and prepares private product/pad checks. Only then can its temporary rows
 * go away. The existing link looks up their digest before calling a reader;
 * missing/evicted entries and local fallback must fail, never upload or use
 * an absent source. No worker cache claim replaces product verification. */
static int sh_required_cache_read(void *ctx, uint64_t, uint8_t *, size_t) {
    const auto *e = static_cast<const sh_state::entry *>(ctx);
    fprintf(stderr, "[shielded] %s: required public worker cache unavailable; no local weight copy retained\n", e->name.c_str());
    return -1;
}

static bool sh_register(sh_state &s, const ggml_tensor *w, sh_source_prefetch *prefetch = nullptr,
                        const ggml_tensor *next_source = nullptr,
                        int64_t split_col0 = 0, int64_t split_ncols = 0) {
    if (s.weight_cache_failed || s.source_verification_failed) return false;
    const std::string name = ggml_get_name(w);
    if (s.weights.count(name)) return true;
    if (s.refused.count(name)) return false;

    const int64_t K = w->ne[0], N = w->ne[1];
    const sh_calib_site *site = sh_site_for(s, name.c_str());
    if (!site) return false;
    const char *only = getenv("SHIELDED_PUBLIC_WEIGHT_CACHE_ONLY");
    const bool cache_only = only && !strcmp(only, "1");
    const char *pc = getenv("SHIELDED_PUBLIC_WEIGHT_CACHE");
    const char *pad_check = getenv("SHIELDED_PAD_CHECK");
    if ((only && *only && strcmp(only, "0") && !cache_only) ||
        (cache_only && (!g_weight_verifier || !pc || strcmp(pc, "1") ||
                        !pad_check || !*pad_check || !strcmp(pad_check, "0")))) {
        fprintf(stderr, "[shielded] %s: required public cache needs authenticated weights, public cache and pad checks\n", name.c_str());
        s.weight_cache_failed = true;
        return false;
    }
    if (!sh_layout_fits(K, N, sh_max_m()))
        return false;
    if (K % SH_QK != 0) return false;
    /* Same pair of gates supports_op applied; registration re-checks them
     * because it is also reached through paths that never asked it. */
    if (!sh_source_type_ok(w->type) || !sh_source_geometry_ok(w->type, K)) return false;
    /* REPACKED ROWS ARE NOT THIS TENSOR'S ROWS. The CPU backend's extra buffer
     * types rewrite a weight into interleaved blocks at load time (ARM: q8_0 ->
     * q8_0_4x8 with dotprod/i8mm; x86/AVX2: q4_K -> q4_K_8x8, iq4_nl, q2_K and
     * friends), keeping the tensor's TYPE tag while changing its bytes. Reading
     * them as the type says would encode a weight nobody computes with -- and
     * that is not a loud failure: the card is verified against OUR encoding, so
     * wrong-but-consistent products would pass Freivalds and the model would
     * just be quietly wrong. On ARM it showed up as "no exponent fits", which is
     * the symptom; this is the cause, and it is checked on every architecture
     * because the x86 types that repack are exactly the ones a k-quant model is
     * made of.
     *
     * Two ways out, both at model load, neither of them here: llama's
     * `use_extra_bufts = false` (what shielded-calib does), or a ggml-cpu built
     * with GGML_CPU_REPACK=OFF. Until then such a weight stays in the enclave,
     * which is correct and merely slow. */
    if (w->buffer && strstr(ggml_backend_buft_name(ggml_backend_buffer_get_type(w->buffer)), "REPACK")) {
        SH_LOG("%s: lives in a %s buffer - the CPU backend repacked its %s rows, so its bytes are no longer that type; "
               "staying in the enclave (load the model with use_extra_bufts=false, or build ggml-cpu with GGML_CPU_REPACK=OFF)\n",
               name.c_str(), ggml_backend_buft_name(ggml_backend_buffer_get_type(w->buffer)), ggml_type_name(w->type));
        s.refused.insert(name);
        return false;
    }

    /* Reservation budget: place calibrated weights until this tenant's slice of
     * the card is full, then leave the rest on CPU. `dev_add` is the device
     * memory this weight would cost the link - its installed int8 matrix plus
     * this node's x/y activation buffers (sh_link_add_weight's abytes growth) -
     * the same bytes the worker charges to the reservation. Checked BEFORE the
     * O(K*N) encoding below, so a weight that will not fit costs nothing. This
     * is what makes a partial offload settle instead of overflowing the worker
     * (see sh_state::reserve_cap). */
    /* A column-split card is charged for the columns it actually receives. */
    const int64_t reg_N = (split_ncols > 0 && split_ncols <= N) ? split_ncols : N;
    const int64_t dev_add = K * reg_N + (int64_t)sh_max_m() * (3 * K + reg_N * 4);
    if (s.reserve_cap > 0 && s.device_bytes + dev_add > s.reserve_cap) {
        if (!s.budget_full_logged) {
            SH_LOG("reservation full: %lld of %lld device bytes placed; %s and later "
                   "calibrated sites stay on CPU (raise the GPU share to offload more)\n",
                   (long long)s.device_bytes, (long long)s.reserve_cap, name.c_str());
            s.budget_full_logged = true;
        }
        s.refused.insert(name);
        return false;
    }

    const double t0 = sh_now_ms();
    const bool profile_registration = getenv("SHIELDED_PROFILE") != nullptr;
    double source_read_ms = 0, source_auth_ms = 0;
    sh_state::entry e;
    e.K = K; e.N = N; e.site = site; e.group = sh_group_key(name);
    /* ---- catalog hit path: ONE authenticated read of the encoded rows replaces source read + auth + encode + cache
     * create; everything from the outlier extraction onward is unchanged. ABSENT (1) -> the source path below;
     * PRESENT-but-invalid (< 0), a geometry/count mismatch, an unreadable block or an out-of-range exponent -> refuse
     * and abort the load (never a fallback). ---- */
    bool hit = false; double t_source = 0, t_encode = 0, catalog_read_ms = 0;
    if (g_encoded_source) {   /* the setter admitted the hook only with a verifier installed; a PRESENT error is fatal regardless */
        ggml_shielded_encoded_entry ce; memset(&ce, 0, sizeof ce); ce.fd = -1;
        const int hr = g_encoded_source(g_encoded_source_ctx, name.c_str(), (uint32_t)w->type, w->ne, &ce);
        if (hr != 0 && hr != 1) { fprintf(stderr, "[shielded] %s: catalog entry present but invalid (%d); aborting model load\n", name.c_str(), hr); s.source_verification_failed = true; s.weight_cache_failed = true; s.refused.insert(name); return false; }   /* both flags: the registration loop aborts on either, verifier or not */
        if (hr == 0) {
            const double tr = sh_now_ms();
            const int64_t af_h = (int64_t)site->act_frac + sh_af_delta(s);
            std::vector<std::array<uint8_t, 32>> digests;
            bool ok = sh_encoded_entry_ok(ce.fd, ce.bytes, ce.blocks, ce.rows, K, N) && ce.block_sha256 && ce.f_w_le32;
            if (ok) { try { digests.resize(ce.blocks); for (size_t b = 0; b < ce.blocks; b++) memcpy(digests[b].data(), ce.block_sha256 + 32 * b, 32); } catch (const std::bad_alloc &) { ok = false; } catch (const std::length_error &) { ok = false; } }
            std::unique_ptr<sh_weight_cache> reader = ok ? sh_weight_cache::open_catalog_sha256(ce.fd, ce.bytes, digests) : nullptr;
            ok = ok && reader != nullptr;
            if (ok) { try { e.w.resize((size_t)K * N); } catch (const std::bad_alloc &) { ok = false; } catch (const std::length_error &) { ok = false; } }
            const bool read_failed = ok && reader->read(0, (uint8_t *)e.w.data(), e.w.size()) != 0;   /* every block verified against the catalog */
            ok = ok && !read_failed;
            ok = ok && sh_encoded_decode_f_w_le32(ce.f_w_le32, ce.rows, af_h, e.f_w);   /* explicit LE int32, range-checked */
            if (read_failed) sh_encoded_failed(name, "block differs from the catalog");   /* the artifact's own bytes: name it, so THAT file is retired */
            if (!ok) { fprintf(stderr, "[shielded] %s: catalog-authenticated encoded weights refused (%s); aborting model load\n", name.c_str(), read_failed ? "a block differs from the catalog" : "geometry or exponent"); s.source_verification_failed = true; s.weight_cache_failed = true; s.refused.insert(name); return false; }
            e.w_cache = std::move(reader); e.source_verified = true; e.encoded_hit = true; hit = true;
            catalog_read_ms = sh_now_ms() - tr; t_source = t_encode = profile_registration ? sh_now_ms() : 0;
        }
    }
    if (!hit) {
    const void *source = w->data;
    sh_source_bytes private_source;
    if (g_weight_verifier) {
        // Hashing the mapping and encoding it afterwards would race hostile
        // page replacements. Copy first; authenticate and encode this copy.
        /* The authenticated copy covers the tensor's OWN bytes, whatever its
         * quantization: the verifier is told w->type and w->ne and checks the
         * digest of what the host supplied. Conversion happens after, on this
         * private copy, so a hostile page replacement still cannot reach it. */
        const size_t nbytes = ggml_nbytes(w);
        bool valid = sh_source_type_ok(w->type) && sh_source_geometry_ok(w->type, K) && K > 0 && N > 0 &&
                     w->ne[2] == 1 && w->ne[3] == 1 && ggml_is_contiguous(w) && source &&
                     nbytes == (size_t)ggml_row_size(w->type, K) * (size_t)N;
        if (valid) {
            const size_t bytes = nbytes;
            double tr = profile_registration ? sh_now_ms() : 0;
            auto ready = prefetch ? prefetch->take(w) : nullptr;
            const bool prefetched = ready && ready->status != 0;
            if (prefetched) {
                valid = ready->status == 1 && ready->bytes.size() == bytes;
                if (valid) private_source = std::move(ready->bytes);
            } else {
                try { private_source.resize(bytes); }
                catch (const std::bad_alloc &) { valid = false; }
                catch (const std::length_error &) { valid = false; }
            }
            if (valid) {
                if (!prefetch) tr = profile_registration ? sh_now_ms() : 0;
                if (!prefetched) {
                    if (sh_is_weight_source(w)) valid = sh_source_read_for_registration(w, private_source.data(), bytes);
                    else memcpy(private_source.data(), source, bytes);
                }
                const double ta = profile_registration ? sh_now_ms() : 0;
                if (valid && prefetch) prefetch->start(next_source);
                valid = valid && g_weight_verifier(g_weight_verifier_ctx, name.c_str(), (uint32_t)w->type,
                                                   w->ne, private_source.data(), bytes) == SH_OK;
                if (profile_registration) {
                    source_read_ms = ta - tr;
                    source_auth_ms = sh_now_ms() - ta;
                }
                source = private_source.data();
            }
        }
        if (!valid) {
            fprintf(stderr, "[shielded] %s: source weight authentication failed; aborting model load\n", name.c_str());
            s.source_verification_failed = true;
            s.refused.insert(name);
            return false;
        }
        e.source_verified = true;
    }
    t_source = profile_registration ? sh_now_ms() : 0;
    e.w.resize((size_t)K * N);
    e.f_w.resize((size_t)N);
    /* Rows are independent: spread the encoding over threads. Registration
     * runs inside the engine's context creation (ggml_backend_sched reserve
     * asks supports_op with the data present), serially per weight, and was
     * 3.4 s of the 0.5B's and 32 s of the 4B's start-up before this. */
    if (sh_prepare_rows_threaded(source, w->type, K, N, e.w.data(), e.f_w.data()) < 0) {
        SH_LOG("%s: no weight exponent fits the int8 lane; staying on CPU\n", name.c_str());
        s.refused.insert(name);
        return false;
    }
    if (w->type != GGML_TYPE_Q8_0)
        SH_LOG("%s: %s source converted to the tier's encoding\n", name.c_str(), ggml_type_name(w->type));
    // Encoding has consumed every authenticated source byte. Release this
    // potentially GiB-sized copy before cache writeback and worker upload;
    // all remaining registration work reads the encoded rows in e.w.
    sh_source_bytes().swap(private_source);
    source = nullptr;
    t_encode = profile_registration ? sh_now_ms() : 0;
    }   /* !hit */

    /* The outlier columns, kept in the TEE. Their contribution is computed here
     * in plain int64 where nothing can wrap, and the offloaded activation has
     * those channels zeroed -- so the channels that would have broken Z_M are
     * exactly the ones the field never has to hold. */
    const size_t nout = site->outliers.size();
    /* Only the card that owns column 0 keeps the full-width outlier and
     * descale tables: they are read once per exchange over the WHOLE row,
     * from the entry the caller holds, which is that card's. */
    const bool split_primary = split_ncols == 0 || split_col0 == 0;
    e.out_cols.resize(split_primary ? nout * (size_t)N : 0);
    for (size_t c = 0; split_primary && c < nout; c++) {
        const int64_t k = site->outliers[c];
        if (k < 0 || k >= K) { SH_LOG("%s: outlier channel %lld out of range\n", name.c_str(), (long long)k); s.refused.insert(name); return false; }
        for (int64_t j = 0; j < N; j++) e.out_cols[c * (size_t)N + j] = e.w[(size_t)j * K + k];
    }
    for (size_t c = 0; !split_primary && c < nout; c++) {
        const int64_t k = site->outliers[c];
        if (k < 0 || k >= K) { SH_LOG("%s: outlier channel %lld out of range\n", name.c_str(), (long long)k); s.refused.insert(name); return false; }
    }
    const int64_t af = (int64_t)site->act_frac + sh_af_delta(s);
    if (af < -149 || af > 127) {
        SH_LOG("%s: activation exponent cannot produce a finite positive float scale; staying on CPU\n", name.c_str());
        s.refused.insert(name); return false;
    }
    e.act_scale = ldexpf(1.0f, (int)af);
    // A public power-of-two bound keeps every local outlier sum inside int64,
    // including its already-unmasked field term. The normal, non-outlier
    // lanes get the stricter Freivalds bound after the outliers are removed.
    uint64_t limit = (uint64_t)SH_FV_X_LIMIT;
    if (nout) {
        const uint64_t safe = ((uint64_t)INT64_MAX - SH_HALF_M) / SH_WEIGHT_BYTE_LIMIT / nout;
        limit = UINT64_C(1) << 62;
        while (limit > safe) limit >>= 1;
    }
    if (limit < (uint64_t)SH_FV_X_LIMIT) { s.refused.insert(name); return false; }
    e.encode_limit = (float)limit;
    e.inv.resize(split_primary ? (size_t)N : 0);
    const double worst_y = (double)SH_HALF_M + (double)nout * SH_WEIGHT_BYTE_LIMIT * (double)limit;
    for (int64_t j = 0; split_primary && j < N; j++) {
        const int64_t exponent = -(af + (int64_t)e.f_w[j]);
        const float inv = exponent < -149 || exponent > 127 ? 0 : ldexpf(1.0f, (int)exponent);
        if (!(inv > 0) || !std::isfinite(inv) || (double)inv * worst_y > (double)FLT_MAX / 2) {
            SH_LOG("%s: output exponent cannot safely descale the supported integer range; staying on CPU\n", name.c_str());
            s.refused.insert(name); return false;
        }
        e.inv[j] = inv;
    }

    if (!s.link) {
        int err = SH_OK;
        s.link = sh_link_open(s.host.c_str(), s.port, true, &err);
        if (!s.link) { s.link_failed = true; return false; }
        if (g_win_fn) sh_link_set_window_provider(s.link, g_win_fn, g_win_ctx);
        if (s.explicit_link) {
            sh_link_configure(s.link, s.vsock_port, s.reserve_bytes, s.refill_threads);
            // Even an empty path is explicit: a global legacy SHM setting
            // must never bind several pooled cards to the same BAR.
            sh_link_configure_shm(s.link, s.shm_path.c_str(), s.shm_bytes);
        }
    }
    int lo = e.f_w[0], hi = e.f_w[0];
    for (int64_t j = 1; j < N; j++) { if (e.f_w[j] < lo) lo = e.f_w[j]; if (e.f_w[j] > hi) hi = e.f_w[j]; }

    const double t_setup = profile_registration ? sh_now_ms() : 0;
    // Dealt decoding needs only the check vectors and outlier columns in RAM.
    // Cache before committing the node, so an I/O failure cannot leave a link
    // borrowing a destroyed vector. No change to dealer/local-mint builds.
    const char *cache_dir = getenv("SHIELDED_WEIGHT_CACHE_DIR");
    if (cache_only && !sh_link_is_dealt(s.link)) {
        fprintf(stderr, "[shielded] %s: required public cache needs a dealt link\n", name.c_str());
        s.weight_cache_failed = true;
        return false;
    }
    if (!cache_only && !hit && cache_dir && *cache_dir && sh_link_is_dealt(s.link)) {   /* a hit already carries the catalog reader */
        e.w_cache = sh_weight_cache::create(cache_dir, e.w.data(), e.w.size());
        if (!e.w_cache) {
            fprintf(stderr, "[shielded] %s: cannot create authenticated encoded-weight cache; aborting model load (check cache storage and I/O)\n", name.c_str());
            s.weight_cache_failed = true;
            s.refused.insert(name);
            return false;
        }
    }

    const double t_cache = profile_registration ? sh_now_ms() : 0;
    /* A column-split card registers ONLY its slice of the rows. The encoding is
     * row-per-output-column, so the slice is contiguous and the link needs no
     * notion of the split at all: it sees a narrower weight. */
    if (split_ncols > 0 && split_ncols < N) {
        if (split_col0 < 0 || split_col0 + split_ncols > N) { s.refused.insert(name); return false; }
        std::vector<int8_t> slice(e.w.begin() + (size_t)split_col0 * K,
                                  e.w.begin() + (size_t)(split_col0 + split_ncols) * K);
        e.w.swap(slice);
        e.f_w.assign(e.f_w.begin() + split_col0, e.f_w.begin() + split_col0 + split_ncols);
    }
    const int64_t link_N = (split_ncols > 0 && split_ncols <= N) ? split_ncols : N;
    sh_state::entry &stored = s.weights[name];
    stored = std::move(e);
    stored.name = name;
    stored.col0 = split_col0; stored.ncols = split_ncols;
    auto gf = s.group_first.find(stored.group);
    const int share = gf == s.group_first.end() ? -1 : gf->second;
#if defined(SHIELDED_COMPACT) && !defined(SHIELDED_DEALER_MODE)
    // A later graph (notably MTP drafting) can discover another weight after
    // prefill opened the link. Registration already excludes active exchanges;
    // stop refill users and close the old upload before attaching its private
    // adapter. Quiesce burns unused pads and preserves integrity latches and
    // mask counters. The dirty plan reconnects with the complete registry.
    if (sh_env_int("SHIELDED_COMPACT_WEIGHTS", 0) && !sh_link_is_dealt(s.link))
        sh_link_quiesce(s.link);
#endif
    const int node = sh_link_add_weight(s.link, name.c_str(), stored.w.data(), K, link_N, sh_max_m(), share);
    if (node < 0) {
        SH_LOG("%s: %s\n", name.c_str(), sh_link_last_error(s.link));
        s.weights.erase(name); s.refused.insert(name);
        return false;
    }
    const double t_checks = profile_registration ? sh_now_ms() : 0;
    stored.node = node;
    if (cache_only) {
        if (sh_link_set_weight_reader(s.link, node, sh_required_cache_read, &stored) != SH_OK) {
            // Keep the borrowed vector alive on failure; the entire model
            // load is now refused before any execution or pad consumption.
            s.weight_cache_failed = true;
            return false;
        }
        const size_t bytes = stored.w.size();
        std::vector<int8_t>().swap(stored.w);
        stored.w_cache.reset(); stored.w_cache_ctx.reset();
        fprintf(stderr, "[shielded] %s: required public cache, released %zu encoded bytes after private checks\n", name.c_str(), bytes);
    } else if (stored.w_cache) {
        int rrc;
        if (stored.encoded_hit) { stored.w_cache_ctx.reset(new sh_encoded_reader_ctx{ stored.w_cache.get(), name }); rrc = sh_link_set_weight_reader(s.link, node, sh_encoded_reader, stored.w_cache_ctx.get()); }
        else rrc = sh_link_set_weight_reader(s.link, node, sh_weight_cache::reader, stored.w_cache.get());
        if (rrc == SH_OK) {
            const size_t bytes = stored.w.size();
            std::vector<int8_t>().swap(stored.w);
            SH_LOG("%s: cached %zu encoded bytes, %zu bytes of trusted block hashes retained (%s)\n",
                   name.c_str(), bytes, stored.w_cache->hash_bytes(), stored.w_cache->hash_algorithm());
        } else {
            // A live link or missing pad check cannot discard its source.
            // Retain the original lifetime contract and report that explicitly.
            fprintf(stderr, "[shielded] %s: compact cache not admitted; encoded weights retained in RAM\n", name.c_str());
            stored.w_cache.reset(); stored.w_cache_ctx.reset();
        }
    }
#if defined(SHIELDED_COMPACT) && !defined(SHIELDED_DEALER_MODE)
    if (sh_env_int("SHIELDED_COMPACT_WEIGHTS", 0) && !sh_link_is_dealt(s.link) && !stored.w.empty()) {
        stored.compact.reset(sh_compact_create(stored.w.data(), K, link_N));
        if (!stored.compact || sh_link_set_local_weight_source(s.link, node,
                sh_compact_read, sh_compact_refill, stored.compact.get()) != SH_OK) {
            // Keep the borrowed raw vector alive until link teardown on failure.
            s.weight_cache_failed = true;
            fprintf(stderr, "[shielded] %s: private compact storage admission failed\n", name.c_str());
            return false;
        }
        const size_t original_bytes = stored.w.size();
        std::vector<int8_t>().swap(stored.w);
        fprintf(stderr, "[shielded] %s: private compact weights %zu -> %zu bytes\n",
                name.c_str(), original_bytes, sh_compact_bytes(stored.compact.get()));
    }
#endif
    s.device_bytes += dev_add;   /* committed to the card; counts against reserve_cap */
    if (share < 0) s.group_first[stored.group] = node;
    s.group_members[stored.group].push_back(name);
    if (s.probe_group.empty()) s.probe_group = stored.group;
    s.dirty = true;
    if (profile_registration) {
        const double t_done = sh_now_ms();
        fprintf(stderr, "[shielded] profile registration %s: source=%.3fms (read=%.3fms auth=%.3fms) "
                        "encode=%.3fms local_setup=%.3fms cache=%.3fms link=%.3fms commit=%.3fms total=%.3fms hit=%d catalog_read=%.3fms\n",
                name.c_str(), t_source - t0, source_read_ms, source_auth_ms,
                t_encode - t_source, t_setup - t_encode, t_cache - t_setup,
                t_checks - t_cache, t_done - t_checks, t_done - t0, hit ? 1 : 0, catalog_read_ms);
    }
    SH_LOG("registered %s K=%lld N=%lld f_w=%d..%d act_frac=%d outliers=%zu group=%s (%.0f ms)\n",
           name.c_str(), (long long)K, (long long)N, lo, hi, site->act_frac, nout, stored.group.c_str(), sh_now_ms() - t0);
    return true;
}

static std::string sh_layer_key(const std::string &name) {
    const size_t blk = name.find("blk.");
    if (blk != std::string::npos) {
        const size_t end = name.find('.', blk + 4);
        if (end != std::string::npos) return name.substr(0, end);
    }
    return sh_group_key(name);
}
static int64_t sh_weight_bytes(const ggml_tensor &w) {
    return w.ne[0] * w.ne[1] + (int64_t)sh_max_m() * (3*w.ne[0] + 4*w.ne[1]);
}
static void sh_plan(sh_pool &p) {
    if (p.invalid || p.pending.empty()) return;
    using weights = std::vector<const ggml_tensor *>;
    std::map<std::string, std::map<std::string, weights>> layers;
    for (auto &kv : p.pending)
        layers[sh_layer_key(kv.first)][sh_group_key(kv.first)].push_back(&kv.second);
    const char *ahead = getenv("SHIELDED_SOURCE_PREFETCH");
    const bool want_ahead = ahead && !strcmp(ahead, "1");
    if ((ahead && *ahead && strcmp(ahead, "0") && !want_ahead) ||
        (want_ahead && (!g_weight_verifier || g_encoded_source))) {
        p.cards[0]->source_verification_failed = true;
        fprintf(stderr, "[shielded] source prefetch requires authenticated raw sources and a 0/1 control\n");
        p.pending.clear(); return;
    }
    sh_source_prefetch prefetch;
    weights ordered;
    if (want_ahead) {
        for (auto &layer : layers) for (auto &group : layer.second)
            ordered.insert(ordered.end(), group.second.begin(), group.second.end());
        fprintf(stderr, "[shielded] source prefetch: one reader, at most %zu extra private bytes; registration read timing includes only unhidden wait\n", sh_source_prefetch::cap);
    }
    size_t source_index = 0;
    auto fit = [&](int c, int64_t bytes) {
        auto &s = *p.cards[c];
        return !s.reserve_cap || s.device_bytes + bytes <= s.reserve_cap;
    };
    auto choose = [&](int64_t bytes) {
        int best = -1;
        for (size_t c = 0; c < p.cards.size(); c++) {
            if (!fit((int)c, bytes)) continue;
            auto &s = *p.cards[c];
            if (best < 0) { best = (int)c; continue; }
            auto &b = *p.cards[best];
            const double used = (double)s.device_bytes / (s.reserve_cap ? s.reserve_cap : INT64_MAX);
            const double prev = (double)b.device_bytes / (b.reserve_cap ? b.reserve_cap : INT64_MAX);
            if (used < prev || (used == prev && s.reserve_cap > b.reserve_cap)) best = (int)c;
        }
        return best;
    };
    if (sh_split_cols() && p.cards.size() > 1) {
        /* Column split: card c holds columns [n_c, n_{c+1}) of EVERY weight, so
         * one exchange occupies every card. Boundaries are 32-column aligned
         * (the worker's kernel plans in column blocks) and the last card takes
         * the remainder. Owner 0 is nominal: the graph walker hands the whole
         * run to card 0, which fans each exchange out. */
        const size_t nc = p.cards.size();
        for (auto &layer : layers) for (auto &grp : layer.second) {
            p.owners[grp.first] = 0;
            for (auto *w : grp.second) {
                const int64_t N = w->ne[1];
                const std::string wname = ggml_get_name(w);
                /* SHIELDED_SPLIT_WEIGHTS: relative shares, e.g. "53,47" for a
                 * pair of cards whose bandwidth differs. Absent = equal. */
                static std::vector<int> share = []{
                    std::vector<int> v;
                    const char *e = getenv("SHIELDED_SPLIT_WEIGHTS");
                    for (const char *p = e; p && *p; ) {
                        char *end = nullptr; long x = strtol(p, &end, 10);
                        if (end == p || x <= 0 || x > 1000) { v.clear(); break; }
                        v.push_back((int)x); p = *end ? end + 1 : end;
                    }
                    return v;
                }();
                const bool weighted = share.size() == nc;
                int64_t share_total = 0;
                for (size_t c = 0; weighted && c < nc; c++) share_total += share[c];
                std::vector<int64_t> edge(nc + 1, 0);
                for (size_t c = 1; c < nc; c++) {
                    int64_t cum = 0;
                    if (weighted) for (size_t d = 0; d < c; d++) cum += share[d];
                    int64_t e = weighted ? ((N * cum / share_total) & ~(int64_t)31)
                                         : ((N * (int64_t)c / (int64_t)nc) & ~(int64_t)31);
                    if (e < edge[c - 1]) e = edge[c - 1];
                    if (e > N) e = N;
                    edge[c] = e;
                }
                edge[nc] = N;
                bool ok = true;
                for (size_t c = 0; c < nc && ok; c++) {
                    const int64_t ncols = edge[c + 1] - edge[c];
                    if (ncols <= 0) { ok = false; break; }
                    ok = sh_register(*p.cards[c], w, nullptr, nullptr, edge[c], ncols);
                    if (!ok) SH_LOG("split: %s slice %lld..%lld refused on card %zu\n", wname.c_str(),
                                    (long long)edge[c], (long long)edge[c + 1], c);
                    if (p.cards[c]->weight_cache_failed || p.cards[c]->source_verification_failed) { p.pending.clear(); return; }
                }
                auto pit = p.cards[0]->weights.find(wname);
                if (!ok || pit == p.cards[0]->weights.end()) {
                    /* Any card refusing its slice makes the whole weight local:
                     * a half-registered weight has no complete product. */
                    for (size_t c = 0; c < nc; c++) p.cards[c]->weights.erase(wname);
                    p.owners.erase(grp.first);
                    continue;
                }
                pit->second.part_cards.clear(); pit->second.part_nodes.clear(); pit->second.part_col0.clear();
                for (size_t c = 0; c < nc; c++) {
                    auto it = p.cards[c]->weights.find(wname);
                    pit->second.part_cards.push_back((int)c);
                    pit->second.part_nodes.push_back(it->second.node);
                    pit->second.part_col0.push_back(it->second.col0);
                }
                SH_LOG("split placement %s over %zu cards (N=%lld)\n", wname.c_str(), nc, (long long)N);
            }
        }
        p.pending.clear();
        sh_release_consumed_sources(p);
        return;
    }
    for (auto &layer : layers) {
        int64_t total = 0;
        for (auto &g : layer.second) for (auto *w : g.second) total += sh_weight_bytes(*w);
        auto prev = p.layers.find(layer.first);
        int preferred = prev == p.layers.end() ? choose(total) : prev->second;
        // Prefer keeping a whole layer together. If it exceeds any one slice,
        // place indivisible activation groups across cards, then CPU overflow.
        for (auto &g : layer.second) {
            int64_t bytes = 0;
            for (auto *w : g.second) bytes += sh_weight_bytes(*w);
            auto old = p.owners.find(g.first);
            int card = old != p.owners.end() ? old->second :
                preferred >= 0 && fit(preferred, bytes) ? preferred : choose(bytes);
            p.owners[g.first] = card;
            if (card < 0) {
                if (g_weight_verifier) {
                    p.cards[0]->source_verification_failed = true;
                    fprintf(stderr, "[shielded] %s: authenticated placement has no capacity; aborting model load\n", g.first.c_str());
                    p.pending.clear(); return;
                }
                SH_LOG("placement %s -> CPU (pool reservation full)\n", g.first.c_str()); continue;
            }
            if (prev == p.layers.end()) p.layers[layer.first] = card;
            SH_LOG("placement %s -> card %d %s:%d (%lld bytes)\n", g.first.c_str(), card,
                   p.cards[card]->host.c_str(), p.cards[card]->port, (long long)bytes);
            for (auto *w : g.second) {
                const ggml_tensor *next = want_ahead && ++source_index < ordered.size() ? ordered[source_index] : nullptr;
                if (!sh_register(*p.cards[card], w, want_ahead ? &prefetch : nullptr, next) && g_weight_verifier) {
                    p.cards[card]->source_verification_failed = true;
                    fprintf(stderr, "[shielded] %s: authenticated registration failed; aborting model load\n", ggml_get_name(w));
                }
                if (p.cards[card]->weight_cache_failed || p.cards[card]->source_verification_failed) { p.pending.clear(); return; }
            }
        }
    }
    p.pending.clear();
    sh_release_consumed_sources(p);
}

/* --------------------------------------------------------------------------
 * The backend
 * ----------------------------------------------------------------------- */
static const char *ggml_backend_shielded_get_name(ggml_backend_t) { return "Shielded"; }
static void sh_pool_quiesce(sh_pool &p);
static void ggml_backend_shielded_free(ggml_backend_t backend) {
    auto &p = sh_pool_get();
    std::lock_guard<std::mutex> lock(p.mu);
    GGML_ASSERT(p.backend_refs > 0);
    if (--p.backend_refs == 0) sh_pool_quiesce(p);
    delete backend;
}

/* Claimable at all: a calibrated q8_0 weight times an f32 activation, above the
 * size floor. Collects the public weight metadata on first sight of its data,
 * so the planner knows complete layer sizes before the first exchange.
 * `batch_ok` additionally applies the batch-width policy. */
static bool sh_claimable(const ggml_tensor *op, bool batch_ok) {
    if (op->op != GGML_OP_MUL_MAT) return false;
    const ggml_tensor *src0 = op->src[0];
    const ggml_tensor *src1 = op->src[1];
    if (!src0 || !src1) return false;
    if (!sh_source_type_ok(src0->type)) return false;    /* q8_0, or a quantization we can convert */
    if (src1->type != GGML_TYPE_F32) return false;
    if (op->type != GGML_TYPE_F32) return false;
    if (!ggml_is_contiguous(src0) || !ggml_is_contiguous(src1)) return false;
    if (src0->ne[2] != 1 || src0->ne[3] != 1) return false;
    if (src1->ne[2] != 1 || src1->ne[3] != 1) return false;
    if (src0->ne[0] % SH_QK != 0 || src0->ne[0] % 16 != 0) return false;
    if (!sh_source_geometry_ok(src0->type, src0->ne[0])) return false;
    if (sh_is_repacked(src0)) return false;   /* not this type's bytes any more; sh_register says why */
    /* A weight tensor has a name and calibration; an activation-activation
     * product (attention) has neither, and must never come here -- TwinShield's
     * OutAttnMult is broken at the group sizes real GQA uses. */
    const char *nm = ggml_get_name(src0);
    if (!nm || !*nm) return false;
    if (src0->ne[0] * src0->ne[1] < sh_min_macs()) return false;
    sh_pool &p = sh_pool_get();
    std::lock_guard<std::mutex> lk(p.mu);
    sh_pool_init(p);
    if (p.invalid || !sh_site_for(*p.cards[0], nm)) return false;
    // Collect public weight metadata during scheduler reservation. The first
    // graph then plans whole layers with all their sizes known, rather than
    // filling one GPU while supports_op discovers tensors one at a time.
    int owner = sh_owner(p, src0);
    if (src0->data && (owner < 0 || !p.cards[owner]->weights.count(nm)) && !p.owners.count(sh_group_key(nm)))
        p.pending[nm] = *src0;
    else if (src0->data && owner >= 0 && !p.cards[owner]->weights.count(nm) && !p.cards[owner]->refused.count(nm))
        p.pending[nm] = *src0;
    if (batch_ok && src1->ne[1] > sh_max_m() && !g_weight_verifier) return false;
    if (!g_weight_verifier && p.owners.count(sh_group_key(nm)) && owner < 0) return false;
    if (!g_weight_verifier && owner >= 0 && p.cards[owner]->contention.contended && sh_group_key(nm) != p.cards[owner]->probe_group) return false;
    return true;
}

/* Column-split placement: every card holds a slice of every weight's output
 * columns, so one exchange runs on all cards AT ONCE. The alternative (a whole
 * weight per card) uses the cards one at a time, because a token walks the
 * layers in order: the 27B's decode had one V100 idle while the other worked.
 * Each card draws its own pad for the same activation, checks its own slice
 * with its own Freivalds vectors, and writes its own columns of the row. */
static bool sh_split_cols() { static int v = -1; if (v < 0) v = sh_env_int("SHIELDED_SPLIT_COLS", 0); return v != 0; }

/* One worker per non-primary card: the request thread runs card 0's exchange
 * itself and hands the others to these, so the cards overlap. Created on the
 * first split exchange, parked on a condition variable between them. */
/* The per-exchange work that follows the product, for ONE card's columns: the
 * TEE-side outlier term and the per-column descale into the caller's f32
 * tensor. Running it on the card's own worker makes it parallel at no extra
 * synchronisation: at m = 1 these loops are a single thread over a whole row
 * (4 ms per token on the 27B), because there is only one row to spread. */
struct sh_split_post {
    const sh_simd *simd = nullptr;
    const int64_t *x_tee = nullptr;
    size_t nout = 0;
    int32_t m = 0;
    std::vector<int64_t *> y;            /* full-width product row for each visible member */
    std::vector<float *> dst;
    std::vector<const float *> inv;
    std::vector<const int8_t *> out_cols;
    std::vector<int64_t> N;
    std::vector<size_t> xi;              /* each member's position in xents, which is what the slice arrays index */
};
static void sh_split_post_slice(const sh_split_post &p, const int64_t *col0, const int64_t *ncols) {
    /* Each member has its own width, so each has its own slice boundary. */
    for (size_t t = 0; t < p.y.size(); t++) {
        const int64_t N = p.N[t];
        const size_t xi = p.xi[t];
        const int64_t c0 = col0[xi], nc = ncols[xi];
        if (nc <= 0 || c0 < 0 || c0 + nc > N) continue;
        for (int32_t r = 0; r < p.m; r++) {
            int64_t *yr = p.y[t] + (size_t)r * N;
            /* The TEE-side outlier term, over THIS card's columns. The channel
             * rows of the full-width table are still N apart, which is the
             * only thing that differs from the whole-tensor call -- so use the
             * same blocked, double-accumulating kernel rather than a scalar
             * int64 loop. The scalar form is exactly what that kernel's own
             * comment measured as ~4x more expensive, and at 2.1 M columns per
             * card per pass it was costing whole milliseconds a token. */
            if (p.nout) p.simd->outlier_add_stride(p.x_tee + (size_t)r * p.nout,
                                                   p.out_cols[t] + c0, (int)p.nout, nc, N, yr + c0);
            p.simd->descale(yr + c0, p.inv[t] + c0, (size_t)nc, p.dst[t] + (size_t)r * N + c0);
        }
    }
}

/* The handoff is on the token's critical path 241 times, so it spins rather
 * than parking: a condition-variable round trip cost ~28 us per exchange,
 * which is most of what a split saves (the kernel itself halves cleanly --
 * 208 -> 107 us for half a gate|up -- so the dispatch was the whole problem).
 * The worker spins for SHIELDED_SPLIT_SPIN_US before falling back to the
 * condition variable, so an idle link does not burn a core. */
struct sh_split_worker {
    std::thread th;
    std::mutex mu; std::condition_variable cv;
    std::atomic<uint64_t> gen{0}, done{0};
    std::atomic<bool> quit{false};
    sh_link *link = nullptr; const int *nodes = nullptr; size_t n = 0;
    const int64_t *x = nullptr; int32_t m = 0; int64_t **y = nullptr; const int64_t *stride = nullptr;
    const sh_split_post *post = nullptr; const int64_t *col0 = nullptr, *ncols = nullptr;
    int rc = SH_OK;
    uint64_t seen = 0;
    /* What the join is made of, measured on the helper's own clock:
     * dispatch -> start, its exchange, its post. Written only by the helper,
     * read at report time. */
    double t_dispatch = 0, t_start_delay = 0, t_gemm = 0, t_post = 0;
    uint64_t runs = 0;
};
/* Context teardown must join library callers before oneDNN's process-exit
 * cache destructors run. Static sh_state teardown alone is too late. Preserve
 * the registry and mask bank so a later context can reconnect safely. */
static void sh_pool_quiesce(sh_pool &p) {
    for (auto *w : p.split_workers) {
        { std::lock_guard<std::mutex> lock(w->mu); w->quit.store(true); }
        w->cv.notify_all();
        if (w->th.joinable()) w->th.join();
        delete w;
    }
    p.split_workers.clear();
    for (auto *s : p.cards) {
        if (s->link) sh_link_quiesce(s->link);
        s->dirty = true;
    }
}
static int sh_split_spin_us() { static int v = -1; if (v < 0) v = sh_env_int("SHIELDED_SPLIT_SPIN_US", 2000); return v; }
static double sh_split_helper_gemm() { double t = 0; for (auto *w : sh_pool_get().split_workers) if (w) t += w->t_gemm; return t; }
static double sh_split_helper_post() { double t = 0; for (auto *w : sh_pool_get().split_workers) if (w) t += w->t_post; return t; }
static void sh_place_report();
static void sh_split_report() {
    sh_place_report();
    for (auto *w : sh_pool_get().split_workers) {
        if (!w || !w->runs) continue;
        fprintf(stderr, "[shielded] split helper: runs=%llu start_delay=%.1fms gemm=%.1fms post=%.1fms "
                        "(per run: %.1f / %.1f / %.1f us)\n",
                (unsigned long long)w->runs, w->t_start_delay, w->t_gemm, w->t_post,
                1000 * w->t_start_delay / w->runs, 1000 * w->t_gemm / w->runs, 1000 * w->t_post / w->runs);
    }
}
static void sh_place_helper_self();
static void sh_split_worker_main(sh_split_worker *w) {
    sh_place_helper_self();
    for (;;) {
        const uint64_t want = w->seen + 1;
        const auto t0 = std::chrono::steady_clock::now();
        for (;;) {
            if (w->gen.load(std::memory_order_acquire) >= want) break;
            if (w->quit) return;
            if (std::chrono::duration_cast<std::chrono::microseconds>(
                    std::chrono::steady_clock::now() - t0).count() > sh_split_spin_us()) {
                std::unique_lock<std::mutex> lk(w->mu);
                w->cv.wait_for(lk, std::chrono::milliseconds(50), [w, want] {
                    return w->quit || w->gen.load(std::memory_order_acquire) >= want; });
                if (w->quit) return;
                if (w->gen.load(std::memory_order_acquire) >= want) break;
            }
            #if defined(__x86_64__)
            __builtin_ia32_pause();
            #endif
        }
        w->seen = want;
        const double ta = sh_now_ms();
        w->t_start_delay += ta - w->t_dispatch;
        const int rc = sh_link_gemm_stride(w->link, w->nodes, w->n, w->x, w->m, w->y, w->stride);
        const double tb = sh_now_ms();
        if (rc == SH_OK && w->post) sh_split_post_slice(*w->post, w->col0, w->ncols);
        w->t_gemm += tb - ta; w->t_post += sh_now_ms() - tb; w->runs++;
        w->rc = rc;
        w->done.store(want, std::memory_order_release);
    }
}

/* One exchange, every card at once. Each card masks the same activation with
 * its OWN pad, computes its own columns, verifies its own slice, and writes
 * straight into this row of the caller's full-width y. */
static int sh_split_exchange(sh_pool &p, std::vector<sh_state::entry *> &xents,
                             std::vector<int64_t *> &yp, const int64_t *x, int32_t m,
                             const sh_split_post *post) {
    const sh_state::entry &e0 = *xents[0];
    const size_t nparts = e0.part_cards.size();
    if (nparts < 2) return SH_ERR_PROTO;
    static std::vector<std::vector<int>> pnodes;
    static std::vector<std::vector<int64_t *>> pyp;
    static std::vector<std::vector<int64_t>> pstride, pcol0, pncols;
    pnodes.resize(nparts); pyp.resize(nparts); pstride.resize(nparts); pcol0.resize(nparts); pncols.resize(nparts);
    for (size_t c = 0; c < nparts; c++) {
        pnodes[c].clear(); pyp[c].clear(); pstride[c].clear(); pcol0[c].clear(); pncols[c].clear();
        for (size_t t = 0; t < xents.size(); t++) {
            const sh_state::entry &e = *xents[t];
            if (e.part_cards.size() != nparts) return SH_ERR_PROTO;
            const int64_t c0 = e.part_col0[c];
            const int64_t c1 = c + 1 < nparts ? e.part_col0[c + 1] : e.N;
            pnodes[c].push_back(e.part_nodes[c]);
            pyp[c].push_back(yp[t] + c0);
            pstride[c].push_back(e.N);
            pcol0[c].push_back(c0);
            pncols[c].push_back(c1 - c0);
        }
    }
    /* SHIELDED_SPLIT_PROBE=n: before the first n exchanges, recompute every
     * card's slice IN THE ENCLAVE and run its own integrity check on it. A
     * slice that fails here has inconsistent check vectors; one that passes
     * here and fails against the worker means the worker holds other bytes. */
    static const int probe_n = sh_env_int("SHIELDED_SPLIT_PROBE", 0);
    static int probed = 0;
    if (probed < probe_n) {
        probed++;
        for (size_t c = 0; c < nparts; c++) {
            sh_state *card = p.cards[e0.part_cards[c]];
            for (size_t t = 0; t < xents.size(); t++) {
                const int nid = pnodes[c][t];
                const int64_t nc = pncols[c][t];
                std::vector<int64_t> scratch((size_t)m * nc, 0);
                int64_t *sp = scratch.data();
                const int lrc = sh_link_gemm_local(card->link, &nid, 1, x, m, &sp);
                const bool ok = lrc == SH_OK && sh_link_verify(card->link, nid, x, scratch.data(), m);
                /* The peak and the local-check bit depend on the activations:
                 * printed only under the plaintext opt-in. No value, ever. */
                const bool plain = sh_fault_diag_plaintext() != 0;
                if (!ok && plain) {
                    /* Exact integer product, unreduced: a peak above M/2 is a
                     * field wrap (which the integer check is meant to catch),
                     * anything else means the check vectors disagree with the
                     * weight this link holds. */
                    const int8_t *W = sh_link_weight(card->link, nid);
                    const int64_t K_ = xents[t]->K;
                    long double peak = 0; int64_t peak_j = -1;
                    if (W) for (int64_t j = 0; j < nc; j++) {
                        long double acc = 0;
                        for (int64_t k2 = 0; k2 < K_; k2++) acc += (long double)x[k2] * W[j * K_ + k2];
                        if (acc < 0 ? -acc > peak : acc > peak) { peak = acc < 0 ? -acc : acc; peak_j = j; }
                    }
                    fprintf(stderr, "[shielded] probe: %s card %zu [plaintext opt-in: exact peak |y| = %.0Lf at col %lld (field M/2 = %lld)]\n",
                            xents[t]->name.c_str(), c, peak, (long long)peak_j, (long long)(SH_M_MOD / 2));
                }
                if (plain)
                    fprintf(stderr, "[shielded] probe: %s card %zu node %d cols %lld+%lld local rc=%d [plaintext opt-in: verify=%d]\n",
                            xents[t]->name.c_str(), c, nid, (long long)pcol0[c][t], (long long)nc, lrc, (int)ok);
                else
                    fprintf(stderr, "[shielded] probe: %s card %zu node %d cols %lld+%lld local rc=%d\n",
                            xents[t]->name.c_str(), c, nid, (long long)pcol0[c][t], (long long)nc, lrc);
            }
        }
    }

    /* SHIELDED_SPLIT_SERIAL=1: same slices, one card after the other on this
     * thread. Isolates the split's arithmetic from its concurrency. */
    static const bool serial = sh_env_int("SHIELDED_SPLIT_SERIAL", 0) != 0;
    if (serial) {
        int rc = SH_OK;
        for (size_t c = 0; c < nparts; c++) {
            sh_state *card = p.cards[e0.part_cards[c]];
            const int r = sh_link_gemm_stride(card->link, pnodes[c].data(), pnodes[c].size(), x, m, pyp[c].data(), pstride[c].data());
            if (r == SH_OK && post) sh_split_post_slice(*post, pcol0[c].data(), pncols[c].data());
            if (rc == SH_OK || r == SH_ERR_VERIFY) rc = r;
            if (c > 0 && r == SH_OK) card->exchanges++;
        }
        return rc;
    }
    while (p.split_workers.size() < nparts - 1) {
        sh_split_worker *w = new sh_split_worker();
        w->th = std::thread(sh_split_worker_main, w);
        p.split_workers.push_back(w);
    }
    for (size_t c = 1; c < nparts; c++) {
        sh_split_worker *w = p.split_workers[c - 1];
        sh_state *card = p.cards[e0.part_cards[c]];
        w->link = card->link; w->nodes = pnodes[c].data(); w->n = pnodes[c].size();
        w->x = x; w->m = m; w->y = pyp[c].data(); w->stride = pstride[c].data();
        w->post = post; w->col0 = pcol0[c].data(); w->ncols = pncols[c].data();
        w->rc = SH_OK;
        const uint64_t g = w->gen.load(std::memory_order_relaxed) + 1;
        w->t_dispatch = sh_now_ms();   /* published by the release store below */
        w->gen.store(g, std::memory_order_release);
        { std::lock_guard<std::mutex> lk(w->mu); w->cv.notify_one(); }   /* only matters if it parked */
    }
    sh_state *card0 = p.cards[e0.part_cards[0]];
    const double ts0 = sh_now_ms();
    int rc = sh_link_gemm_stride(card0->link, pnodes[0].data(), pnodes[0].size(), x, m, pyp[0].data(), pstride[0].data());
    const double ts1 = sh_now_ms();
    if (rc == SH_OK && post) sh_split_post_slice(*post, pcol0[0].data(), pncols[0].data());
    const double ts2 = sh_now_ms();
    card0->t_split_gemm += ts1 - ts0;
    card0->t_split_post += ts2 - ts1;
    for (size_t c = 1; c < nparts; c++) {
        sh_split_worker *w = p.split_workers[c - 1];
        const uint64_t want = w->gen.load(std::memory_order_relaxed);
        while (w->done.load(std::memory_order_acquire) < want) {
            #if defined(__x86_64__)
            __builtin_ia32_pause();
            #endif
        }
        if (rc == SH_OK) rc = w->rc;
        else if (w->rc == SH_ERR_VERIFY) rc = SH_ERR_VERIFY;
    }
    card0->t_split_join += sh_now_ms() - ts2;
    if (rc == SH_OK) {
        for (size_t c = 1; c < nparts; c++) {
            sh_state *card = p.cards[e0.part_cards[c]];
            card->exchanges++;
        }
    }
    return rc;
}

static bool sh_local_islands_enabled() {
    static const bool enabled = sh_env_int("SHIELDED_FUSE_LOCAL", 0) != 0;
    return enabled;
}

/* A scheduling-only precursor to product-weight fusion. Restrict it to the
 * Qwen residual -> post-attention RMSNorm -> public gamma island, with both
 * adjacent sites calibrated. The ordinary matmuls and pad groups are unchanged.
 * This pure matcher can also run while the pool lock is already held. */
static bool sh_local_island_pattern(const ggml_tensor *op, sh_fusion_pattern &out) {
    return sh_local_islands_enabled() && sh_fusion_match_local(op, out);
}

static bool sh_local_island_claimable(const ggml_tensor *op) {
    sh_fusion_pattern pattern;
    if (!sh_local_island_pattern(op, pattern) || !sh_claimable(pattern.first, true)) return false;
    sh_pool &p = sh_pool_get();
    std::lock_guard<std::mutex> lk(p.mu);
    const std::string next = sh_layer_key(ggml_get_name(pattern.first->src[0])) + ".ffn_gate.weight";
    return !p.invalid && sh_site_for(*p.cards[0], next.c_str());
}

static bool sh_compute_local_island(sh_state &s, const ggml_tensor *op, const sh_fusion_pattern &pattern) {
    const double t0 = sh_now_ms();
    const size_t m = (size_t)pattern.add->ne[1];
    if (s.local_inv_rms.size() < m) s.local_inv_rms.resize(m);
    if (!sh_fusion_compute_local(op, pattern, s.local_inv_rms.data(), s.local_inv_rms.size())) return false;
    s.local_island_ops++;
    s.t_local_island += sh_now_ms() - t0;
    return true;
}

/* PILOT (SHIELDED_OVERLAP_CPU=1, off by default): trusted work scheduled into
 * the exchange's idle window.
 *
 * Only local islands whose MUL_MAT is ALREADY COMPUTED are eligible. That is
 * the whole safety argument and it is a property of the selection, not of the
 * timing: such an island reads a product that has already been unmasked and
 * Freivalds-verified, so running it early cannot consume an unverified reply.
 * It never reads the reply in flight, never touches the pipe, and writes only
 * its own scheduler-allocated output.
 *
 * Registered on the PRIMARY card's link only. With a column split the other
 * card's helper is running concurrently, and one owner for the deferred set
 * keeps it single-threaded rather than needing a claim protocol. */
static int sh_overlap_cpu_mode() {
    /* 0 off, 1 select and compute, 2 select but compute NOTHING -- mode 2
     * separates "the hook fires" from "the work ran early" when the pilot
     * misbehaves, without changing selection. */
    static const int m = sh_env_int("SHIELDED_OVERLAP_CPU", 0);
    return m;
}
static bool sh_overlap_cpu_enabled() { return sh_overlap_cpu_mode() != 0; }
/* Phase-trace records, buffered. Written once, at exit, so nothing in the
 * measured path does I/O.
 *
 * LIFETIME. The first version held the records in a function-local static
 * vector and registered atexit(flush) from a DIFFERENT function-local static
 * initialiser. Exit handlers and static destructors run in reverse order of
 * registration, and the vector was constructed second, so it was destroyed
 * BEFORE the flush ran: a heap-use-after-free on every normal exit, which an
 * independent ASan harness reproduced. The buffer is now a deliberately leaked
 * allocation with no destructor, so it is valid for the whole life of the
 * process including exit handlers.
 *
 * THREADS. Appends are guarded. graph_compute is expected to run on one
 * scheduler thread, but "expected" is how the readiness rule went wrong, and
 * an uncontended mutex costs ~20 ns against ~35k records.
 *
 * CAPACITY. Drops are COUNTED and reported. A truncated trace that does not
 * say it is truncated would let a window claim to cover a phase it does not. */
struct sh_trace_rec { int card; double t; int m; uint64_t graphs, nodes, ex;
                      double idle, link, graph, mask, unmask, rhs, check, pads, wire, pre,
                             sgemm, spost, sjoin, hgemm, hpost, mkern, dwait;
                      uint64_t melems, mslown; double mslow; };
struct sh_trace_state {
    std::vector<sh_trace_rec> v;
    std::mutex mu;
    uint64_t dropped = 0;
};
static sh_trace_state *sh_trace_st() {
    static sh_trace_state *st = [] {           /* leaked on purpose: no destructor */
        auto *p = new sh_trace_state();
        p->v.reserve(1u << 17);
        return p;
    }();
    return st;
}
static void sh_trace_push(int card, double t, int m, uint64_t graphs, uint64_t nodes, uint64_t ex,
                          double idle, double link, double graph,
                          double mask, double unmask, double rhs, double check, double pads, double wire, double pre,
                          double sgemm, double spost, double sjoin, double hgemm, double hpost, double mkern, double dwait,
                          uint64_t melems, uint64_t mslown, double mslow) {
    sh_trace_state *st = sh_trace_st();
    std::lock_guard<std::mutex> lk(st->mu);
    if (st->v.size() < st->v.capacity())
        st->v.push_back({card, t, m, graphs, nodes, ex, idle, link, graph, mask, unmask, rhs, check, pads, wire, pre, sgemm, spost, sjoin, hgemm, hpost, mkern, dwait, melems, mslown, mslow});
    else st->dropped++;
}
static void sh_trace_flush() {
    sh_trace_state *st = sh_trace_st();
    std::lock_guard<std::mutex> lk(st->mu);
    for (const auto &r : st->v)
        fprintf(stderr, "[ph] card=%d t=%.3f m=%d graphs=%llu nodes=%llu ex=%llu idle=%.1f link=%.1f graph=%.1f"
                        " mask=%.1f unmask=%.1f rhs=%.1f check=%.1f pads=%.1f wire=%.1f pre=%.1f sgemm=%.1f spost=%.1f sjoin=%.1f hgemm=%.1f hpost=%.1f mkern=%.1f dwait=%.1f melems=%llu mslown=%llu mslow=%.1f\n",
                r.card, r.t / 1000.0, r.m, (unsigned long long)r.graphs, (unsigned long long)r.nodes,
                (unsigned long long)r.ex, r.idle, r.link, r.graph, r.mask, r.unmask, r.rhs, r.check, r.pads, r.wire, r.pre, r.sgemm, r.spost, r.sjoin, r.hgemm, r.hpost, r.mkern, r.dwait,
                (unsigned long long)r.melems, (unsigned long long)r.mslown, r.mslow);
    if (!st->v.empty() || st->dropped)
        fprintf(stderr, "[ph] flushed %zu records, DROPPED %llu (capacity %zu)\n",
                st->v.size(), (unsigned long long)st->dropped, st->v.capacity());
}
static bool sh_phase_trace() {
    static const bool on = [] {
        const bool v = sh_env_int("SHIELDED_PHASE_TRACE", 0) != 0;
        if (v) { sh_trace_st(); atexit(sh_trace_flush); }   /* construct BEFORE registering */
        return v;
    }();
    return on;
}
struct sh_idle_batch {
    sh_state *st = nullptr;
    std::vector<std::pair<ggml_tensor *, sh_fusion_pattern>> items;
    size_t done_n = 0;               /* how many of `items` actually completed */
};
static void sh_idle_run(void *ctx) {
    sh_idle_batch *b = (sh_idle_batch *)ctx;
    { static int shout = 0; if (shout < 3) { shout++; fprintf(stderr, "[shielded] pilot: window fired, %zu items (mode %d)\n", b->items.size(), sh_overlap_cpu_mode()); } }
    if (sh_overlap_cpu_mode() == 2) return;                 /* selected, deliberately not computed */
    for (auto &it : b->items) {
        if (!sh_compute_local_island(*b->st, it.first, it.second)) return;  /* stop; the rest stay undone */
        b->done_n++;
        b->st->idle_islands++;
    }
}

static int sh_graph_node_owner(sh_pool &p, const ggml_tensor *node) {
    if (node->op == GGML_OP_MUL_MAT) return sh_owner(p, node->src[0]);
    sh_fusion_pattern pattern;
    return sh_local_island_pattern(node, pattern) ? sh_owner(p, pattern.first->src[0]) : -1;
}

/* --------------------------------------------------------------------------
 * The enclave's own CPU, reached through ggml's CPU backend.
 *
 * Every path that computes a claimed matmul in the enclave used to go through
 * the int64 field product (exact, and 6 tok/s on the 0.5B) or a scalar double
 * loop. ggml_backend_sched keeps its split plan across tokens (the engine
 * reuses its graph), so a node the backend claimed once stays ours whether or
 * not it should still go to the card; what the backend can do is compute it
 * HERE, with the CPU backend the engine already loaded, at the CPU's speed --
 * a one-node graph, the node's own sources (they live in host memory, this
 * backend's buffer type is the CPU's), the CPU backend's threads. That is what
 * a contended card falls back to (a game on the 3070 made the offloaded path
 * six times slower than this), and what a dead link falls back to while it
 * reconnects. It rounds like the CPU backend (fp32 accumulate) rather than
 * like the field, so the text may differ from the offloaded path's; both are
 * the model's own arithmetic. SHIELDED_LOCAL_EXACT=1 keeps the int64 field
 * path instead, for the exactness check (its output IS the worker's).
 * ----------------------------------------------------------------------- */
static ggml_backend_t sh_cpu_backend() {
    static ggml_backend_t be = nullptr;
    static bool tried = false;
    if (tried) return be;
    tried = true;
    ggml_backend_dev_t dev = ggml_backend_dev_by_type(GGML_BACKEND_DEVICE_TYPE_CPU);
    if (!dev) return nullptr;
    be = ggml_backend_dev_init(dev, nullptr);
    if (!be) return nullptr;
    ggml_backend_reg_t reg = ggml_backend_dev_backend_reg(dev);
    auto set_threads = reg ? (ggml_backend_set_n_threads_t)ggml_backend_reg_get_proc_address(reg, "ggml_backend_cpu_set_n_threads") : nullptr;
    int nt = sh_env_int("SHIELDED_LOCAL_THREADS", 0);
    if (nt <= 0) { unsigned hw = std::thread::hardware_concurrency(); nt = hw > 2 ? (int)(hw / 2) : 2; if (nt > 8) nt = 8; }
    if (set_threads) set_threads(be, nt);
    return be;
}
static bool sh_cpu_compute(ggml_tensor *node) {
    ggml_backend_t be = sh_cpu_backend();
    if (!be) return false;
    static ggml_context *ctx = nullptr;
    if (!ctx) {
        ggml_init_params ip = { ggml_graph_overhead_custom(8, false) + 1024, nullptr, true };
        ctx = ggml_init(ip);
        if (!ctx) return false;
    }
    ggml_cgraph *gf = ggml_new_graph_custom(ctx, 8, false);
    ggml_graph_add_node(gf, node);
    const enum ggml_status st = ggml_backend_graph_compute(be, gf);
    ggml_reset(ctx);
    return st == GGML_STATUS_SUCCESS;
}
static bool sh_local_exact() { static int v = -1; if (v < 0) v = sh_env_int("SHIELDED_LOCAL_EXACT", 0); return v != 0; }

/* The escape hatch: q8_0 x f32 in the clear, in the enclave.
 *
 * A backend that claims an op and then returns GGML_STATUS_FAILED does not
 * degrade, it kills the graph -- llama_decode turns that into rc -3 and the
 * request dies. That is the right behaviour for a VERIFICATION failure, where
 * continuing would mean sampling a value a hostile worker chose. It is the wrong
 * behaviour for "this weight never registered", which is our own bookkeeping
 * problem and has a correct answer sitting right there in the tensor. */
static void sh_plain_mul_mat(const ggml_tensor *w, const ggml_tensor *a, ggml_tensor *dst) {
    const int64_t K = w->ne[0], N = w->ne[1], m = a->ne[1];
    const int64_t nb = K / SH_QK;
    /* Repacked rows cannot be read as their type here either. The CPU backend
     * owns the traits that understand them, so hand the node to it rather than
     * produce a plausible wrong answer. Claiming refuses these weights up front,
     * so this only catches a tensor whose buffer we could not see then. */
    if (sh_is_repacked(w)) {
        if (dst->src[0] == w && dst->src[1] == a && sh_cpu_compute(dst)) return;
        fprintf(stderr, "[shielded] %s: repacked weight and no CPU backend to compute it with; zeroing\n",
                ggml_get_name(w));
        memset(dst->data, 0, ggml_nbytes(dst));
        return;
    }
    /* A source that is not q8_0 is dequantized a row at a time and multiplied in
     * the same double accumulation. The hatch is rare (a weight we claimed and
     * then could not register), so a row of scratch beats a second encoding. */
    if (w->type != GGML_TYPE_Q8_0) {
        const ggml_type_traits *tr = ggml_get_type_traits(w->type);
        if (!tr || !tr->to_float) { memset(dst->data, 0, ggml_nbytes(dst)); return; }
        const size_t row_bytes = (size_t)ggml_row_size(w->type, K);
        const uint8_t *wb = (const uint8_t *)w->data;
        const float *src = (const float *)a->data;
        float *out = (float *)dst->data;
        std::vector<float> wrow((size_t)K);
        for (int64_t i = 0; i < N; i++) {
            tr->to_float(wb + (size_t)i * row_bytes, wrow.data(), K);
            for (int64_t r = 0; r < m; r++) {
                const float *xr = src + r * K;
                double acc = 0.0;
                for (int64_t t = 0; t < K; t++) acc += (double)xr[t] * (double)wrow[t];
                out[r * N + i] = (float)acc;
            }
        }
        return;
    }
    const sh_block_q8_0 *blocks = (const sh_block_q8_0 *)w->data;
    const float *src = (const float *)a->data;
    float *out = (float *)dst->data;
    for (int64_t r = 0; r < m; r++) {
        const float *xr = src + r * K;
        float *orow = out + r * N;
        for (int64_t i = 0; i < N; i++) {
            double acc = 0.0;
            const sh_block_q8_0 *row = blocks + i * nb;
            for (int64_t b = 0; b < nb; b++) {
                const float d = sh_half_to_float(row[b].d);
                const int8_t *q = row[b].qs;
                const float *xb = xr + b * SH_QK;
                double blk = 0.0;
                for (int t = 0; t < SH_QK; t++) blk += (double)xb[t] * (double)q[t];
                acc += blk * (double)d;
            }
            orow[i] = (float)acc;
        }
    }
}

static bool sh_is_meta(const ggml_tensor *t) {
    switch (t->op) {
        case GGML_OP_NONE: case GGML_OP_RESHAPE: case GGML_OP_VIEW:
        case GGML_OP_PERMUTE: case GGML_OP_TRANSPOSE: return true;
        default: return false;
    }
}

static void sh_note_latency(sh_state &s, const std::string &group, int rows, double us, double weight_bytes) {
    static const double X  = [] { const char *e = getenv("SHIELDED_CONTENTION_X");  return (e && *e) ? atof(e) : 3.0; }();
    static const double US = [] { const char *e = getenv("SHIELDED_CONTENTION_US"); return (e && *e) ? atof(e) : 200.0; }();
    static const double ABS_X = [] { const char *e = getenv("SHIELDED_CONTENTION_ABS_X"); return (e && *e) ? atof(e) : 8.0; }();
    const int change = s.contention.note(group, rows, us, weight_bytes, group == s.probe_group, X, US, ABS_X);
    if (!change) return;
    const auto &l = s.contention.samples.at({group, rows});
    if (change > 0) {
        fprintf(stderr, "[shielded] the card is contended: %s rows=%d exchanges take %.0f us against a best of %.0f; "
                        "computing in the enclave until it recovers (probing with %s)\n",
                group.c_str(), rows, l.ewma, l.best, s.probe_group.c_str());
    } else {
        fprintf(stderr, "[shielded] the card recovered (%s rows=%d exchanges back to %.0f us); offloading again\n",
                group.c_str(), rows, l.ewma);
    }
}

/* The link is down (socket error, worker refused us, or start failed): stop
 * using it and arm the retry. Pads are unaffected -- the bank's counter never
 * rewinds and the pools are rebuilt from fresh issuance on reconnect. */
static void sh_link_down(sh_state &s) {
    s.link_failed = true;
    s.link_retry_at = sh_now_ms() + s.link_backoff_ms;
    s.link_backoff_ms = s.link_backoff_ms < 60000 ? s.link_backoff_ms * 2 : 60000;
}

/* Wide prefill cannot fall through to a discarded original mapping. Reuse
 * the bounded exact encoded-weight path in legal row batches. This is a
 * correctness fallback; the engine should batch prefill for offloading. */
static int sh_local_products(sh_state &s, const std::vector<int> &nodes,
                            const std::vector<sh_state::entry *> &entries,
                            const int64_t *x, int32_t m, int64_t **y) {
    if (!entries.empty() && entries[0]->part_cards.size() > 1) {
        // A link owns only its columns. Reconstruct every authenticated slice
        // into the full-width result, including prefill wider than max_m.
        if (nodes.empty() || nodes.size() > SH_GROUP_MAX || entries.size() != nodes.size() ||
            m <= 0 || sh_max_m() <= 0) return SH_ERR_PROTO;
        sh_pool &pool = sh_pool_get();
        for (size_t t = 0; t < entries.size(); t++) {
            const auto &e = *entries[t];
            if (e.part_nodes.size() != e.part_cards.size() || e.part_col0.size() != e.part_cards.size())
                return SH_ERR_PROTO;
            for (size_t c = 0; c < e.part_cards.size(); c++) {
                const int ci = e.part_cards[c];
                if (ci < 0 || (size_t)ci >= pool.cards.size()) return SH_ERR_PROTO;
                sh_state &card = *pool.cards[ci];
                std::unique_lock<std::mutex> lock(card.mu, std::defer_lock);
                if (&card != &s) lock.lock();
                if (!card.link) return SH_ERR_IO;
                uint64_t failures = 0;
                sh_link_stats(card.link, nullptr, nullptr, &failures);
                if (card.verify_fail || failures) return SH_ERR_VERIFY;
                const int64_t col = e.part_col0[c];
                const int64_t end = c + 1 < e.part_col0.size() ? e.part_col0[c + 1] : e.N;
                if (col < 0 || end <= col || end > e.N || (c == 0 && col != 0)) return SH_ERR_PROTO;
                const size_t width = (size_t)(end - col);
                std::vector<int64_t> slice((size_t)std::min(m, sh_max_m()) * width);
                int64_t *dst = slice.data();
                for (int32_t at = 0; at < m;) {
                    const int32_t rows = std::min(sh_max_m(), m - at);
                    const int rc = sh_link_gemm_local(card.link, &e.part_nodes[c], 1,
                                                      x + (size_t)at * e.K, rows, &dst);
                    if (rc != SH_OK) return rc;
                    for (int32_t r = 0; r < rows; r++)
                        memcpy(y[t] + (size_t)(at + r) * e.N + col,
                               slice.data() + (size_t)r * width, width * sizeof(int64_t));
                    at += rows;
                }
            }
        }
        return SH_OK;
    }
    if (!g_weight_verifier || m <= sh_max_m())
        return sh_link_gemm_local(s.link, nodes.data(), nodes.size(), x, m, y);
    if (nodes.empty() || nodes.size() > SH_GROUP_MAX || entries.size() != nodes.size() || sh_max_m() <= 0)
        return SH_ERR_PROTO;
    int64_t *part[SH_GROUP_MAX];
    for (int32_t at = 0; at < m;) {
        const int32_t rows = std::min(sh_max_m(), m - at);
        for (size_t i = 0; i < nodes.size(); i++) part[i] = y[i] + (size_t)at * entries[i]->N;
        const int rc = sh_link_gemm_local(s.link, nodes.data(), nodes.size(),
                                         x + (size_t)at * entries[0]->K, rows, part);
        if (rc != SH_OK) return rc;
        at += rows;
    }
    return SH_OK;
}

/* Called with the card mutex held. A refill thread can retire the C link
 * between graphs without yet incrementing the backend's own counter. Observe
 * it at entry, including graphs served entirely by verified local caches. */
static bool sh_card_integrity_failed(sh_state &s) {
    if (!s.verify_fail && s.link) {
        uint64_t failures = 0;
        sh_link_stats(s.link, nullptr, nullptr, &failures);
        if (failures) s.verify_fail++;
    }
    return s.verify_fail != 0;
}

/* Opt-in thread placement (off unless SHIELDED_CPU_MAIN is set). A decode
 * round is serialized on two threads -- the thread that runs card 0's link
 * (also OpenMP's master for the CPU ops) and the split helper -- and the
 * join waits on whichever of them could not get a core. Blanket taskset
 * starved the other ~17 threads (REPORT 18.9); this reserves only the two
 * critical cores and their SMT siblings and leaves every other thread the
 * rest of the box (SHIELDED_CPU_REST, e.g. "2-15,18-31").
 *
 * Placement only: no buffer, pad, mask or check path depends on it, and a
 * failed setaffinity changes nothing but where a thread runs. The sweep
 * re-masks every thread of the process that is not one of the two, so
 * OpenMP workers and refill threads created later are caught on the next
 * sweep; a thread already on the right mask is left alone. */
static bool sh_parse_cpus(const char *s, cpu_set_t *set) {
    CPU_ZERO(set);
    if (!s || !*s) return false;
    int n = 0;
    for (const char *p = s; *p; ) {
        char *end = nullptr; long a = strtol(p, &end, 10);
        if (end == p || a < 0 || a >= CPU_SETSIZE) return false;
        long b = a;
        if (*end == '-') { p = end + 1; b = strtol(p, &end, 10); if (end == p || b < a || b >= CPU_SETSIZE) return false; }
        for (long c = a; c <= b; c++) { CPU_SET((int)c, set); n++; }
        p = *end == ',' ? end + 1 : end;
        if (*end && *end != ',') return false;
    }
    return n > 0;
}
struct sh_placement {
    bool on = false;
    cpu_set_t main_set, helper_set, rest_set;
    bool has_helper = false, has_rest = false;
    std::atomic<pid_t> main_tid{0}, helper_tid{0};
    uint64_t sweeps = 0, moved = 0;
};
static sh_placement &sh_place() {
    static sh_placement *p = [] {
        auto *q = new sh_placement();                 /* leaked: threads read it until exit */
        const char *m = getenv("SHIELDED_CPU_MAIN");
        if (m && *m) {
            if (!sh_parse_cpus(m, &q->main_set)) {
                fprintf(stderr, "[shielded] SHIELDED_CPU_MAIN=\"%s\" is not a cpu list; placement off\n", m);
                return q;
            }
            q->has_helper = sh_parse_cpus(getenv("SHIELDED_CPU_HELPER"), &q->helper_set);
            q->has_rest = sh_parse_cpus(getenv("SHIELDED_CPU_REST"), &q->rest_set);
            /* helpers started from here on begin on the rest mask rather than
             * inheriting a pinned creator's one core */
            if (q->has_rest) sh_thread_spawn_cpus(&q->rest_set, sizeof q->rest_set);
            q->on = true;
        }
        return q;
    }();
    return *p;
}
static void sh_place_set(pid_t tid, const cpu_set_t *want, uint64_t *moved) {
    cpu_set_t cur; CPU_ZERO(&cur);
    if (sched_getaffinity(tid, sizeof cur, &cur) == 0 && CPU_EQUAL(&cur, want)) return;
    if (sched_setaffinity(tid, sizeof *want, want) == 0 && moved) (*moved)++;
}
/* Called from the helper itself when it starts. */
static void sh_place_helper_self() {
    sh_placement &p = sh_place();
    if (!p.on) return;
    const pid_t tid = (pid_t)syscall(SYS_gettid);
    p.helper_tid.store(tid);
    if (p.has_helper) sh_place_set(tid, &p.helper_set, nullptr);
}
/* Async callers can change between graphs. Place the active caller on every
 * graph; the less frequent sweep below only handles other idle threads. */
static void sh_place_main_self() {
    sh_placement &p = sh_place();
    if (!p.on) return;
    const pid_t self = (pid_t)syscall(SYS_gettid);
    if (p.main_tid.load() != self) { p.main_tid.store(self); }
    sh_place_set(self, &p.main_set, &p.moved);
}
/* Called by card 0's compute thread, under its state mutex, every 256 graphs. */
static void sh_place_sweep() {
    sh_placement &p = sh_place();
    if (!p.on) return;
    const pid_t self = (pid_t)syscall(SYS_gettid);
    if (!p.has_rest) return;
    const pid_t helper = p.helper_tid.load();
    DIR *d = opendir("/proc/self/task");
    if (!d) return;
    while (struct dirent *e = readdir(d)) {
        if (e->d_name[0] < '0' || e->d_name[0] > '9') continue;
        const pid_t tid = (pid_t)atoi(e->d_name);
        if (tid == self || tid == helper) continue;
        sh_place_set(tid, &p.rest_set, &p.moved);
    }
    closedir(d);
    p.sweeps++;
}

static void sh_place_report() {
    sh_placement &p = sh_place();
    if (!p.on) return;
    const pid_t main_tid = p.main_tid.load(), helper_tid = p.helper_tid.load();
    cpu_set_t a, b; CPU_ZERO(&a); CPU_ZERO(&b);
    const int ma = main_tid ? sched_getaffinity(main_tid, sizeof a, &a) : -1;
    const int mb = helper_tid ? sched_getaffinity(helper_tid, sizeof b, &b) : -1;
    /* Stragglers: any OTHER thread whose mask touches a reserved core (main's
     * or helper's). Nonzero means some thread escaped the rest mask. */
    int threads = 0, stragglers = 0;
    if (DIR *d = opendir("/proc/self/task")) {
        while (struct dirent *e = readdir(d)) {
            if (e->d_name[0] < '0' || e->d_name[0] > '9') continue;
            const pid_t tid = (pid_t)atoi(e->d_name);
            threads++;
            if (tid == main_tid || tid == helper_tid) continue;
            cpu_set_t c; CPU_ZERO(&c);
            if (sched_getaffinity(tid, sizeof c, &c) != 0) continue;
            cpu_set_t x; CPU_AND(&x, &c, &p.main_set);
            bool hit = CPU_COUNT(&x) > 0;
            if (p.has_helper) { CPU_AND(&x, &c, &p.helper_set); hit = hit || CPU_COUNT(&x) > 0; }
            if (hit) stragglers++;
        }
        closedir(d);
    }
    fprintf(stderr, "[shielded] placement: main tid=%d cpus=%d helper tid=%d cpus=%d rest=%s sweeps=%llu moved=%llu threads=%d stragglers=%d\n",
            (int)main_tid, ma == 0 ? CPU_COUNT(&a) : -1, (int)helper_tid, mb == 0 ? CPU_COUNT(&b) : -1,
            p.has_rest ? "yes" : "no", (unsigned long long)p.sweeps, (unsigned long long)p.moved, threads, stragglers);
}

static enum ggml_status sh_card_compute(sh_state &s, ggml_cgraph *cgraph) {
    std::lock_guard<std::mutex> lk(s.mu);
    if (s.card_index == 0) {
        sh_place_main_self();
        if ((s.graph_calls & 255) == 0) sh_place_sweep();
    }
    if (sh_card_integrity_failed(s) || s.weight_cache_failed || s.source_verification_failed) return GGML_STATUS_FAILED;
    const double tg0 = sh_now_ms();
    s.graph_calls++;
    int trace_m = 0;   /* rows of the last offloaded node in this graph, for the phase trace */
    const sh_simd *simd = sh_link_simd();

    const int n = ggml_graph_n_nodes(cgraph);
    /* A failed link is retried once its backoff has passed: the same start
     * path as the first connection, carrying the whole weight set again. */
    if (s.link_failed && s.link && sh_now_ms() >= s.link_retry_at) { s.link_failed = false; s.dirty = true; }
    if (s.link && !s.link_failed && !sh_link_is_live(s.link)) s.dirty = true;
    if (s.dirty && s.link && !s.link_failed) {
        const double t0 = sh_now_ms();
        const int rc = sh_link_start(s.link);
        if (rc == SH_ERR_VERIFY) {
            /* A pad importer or authenticated upload can reject while start
             * is warming the link. Never downgrade this to a retryable bank
             * shortage, and retire the process-wide backend as for a reply. */
            s.verify_fail++;
            fprintf(stderr, "[shielded] integrity failure during start: %s\n", sh_link_last_error(s.link));
            return GGML_STATUS_FAILED;
        }
        if (rc != SH_OK && sh_link_is_dealt(s.link)) {
            /* Dealt pads configured and no way to run them (no window, no
             * shipment, no worker): the same refusal as exhaustion. Computing
             * the whole model in the clear here would be silent and ten times
             * slower; the request fails, the next one retries the start. */
            fprintf(stderr, "[shielded] dealt pads: cannot start (%s); refusing to proceed without dealt pads, retrying in %.0f s\n",
                    sh_link_last_error(s.link), s.link_backoff_ms / 1000);
            sh_link_down(s);
            s.dirty = false;
            return GGML_STATUS_FAILED;
        }
        if (rc != SH_OK) {
            SH_LOG("worker unavailable (%s); computing in the enclave, retrying in %.0f s\n",
                   sh_link_last_error(s.link), s.link_backoff_ms / 1000);
            sh_link_down(s);
        } else {
            SH_LOG("worker live over %s with %zu weights, %d refill threads (%.0f ms to upload, install and warm the pool)\n",
                   sh_link_transport(s.link), s.weights.size(), sh_link_refill_threads(s.link), sh_now_ms() - t0);
            s.link_backoff_ms = 1000;
        }
        s.dirty = false;
    }

    /* A column-split graph reaches only THIS card's compute path, so the other
     * cards' links would never be opened, and every split exchange would fall
     * back to the enclave. Start them here, with the same rules. */
    if (sh_split_cols()) {
        sh_pool &pool = sh_pool_get();
        for (sh_state *o : pool.cards) {
            if (o == &s || !o->link) continue;
            std::lock_guard<std::mutex> olk(o->mu);
            if (o->link_failed && sh_now_ms() >= o->link_retry_at) { o->link_failed = false; o->dirty = true; }
            if (!o->link_failed && !sh_link_is_live(o->link)) o->dirty = true;
            if (!o->dirty || o->link_failed) continue;
            const double t0 = sh_now_ms();
            const int rc = sh_link_start(o->link);
            if (rc == SH_ERR_VERIFY) {
                o->verify_fail++;
                fprintf(stderr, "[shielded] integrity failure during start of %s:%d: %s\n", o->host.c_str(), o->port, sh_link_last_error(o->link));
                return GGML_STATUS_FAILED;
            }
            if (rc != SH_OK) {
                SH_LOG("split: card %s:%d unavailable (%s); retrying in %.0f s\n", o->host.c_str(), o->port,
                       sh_link_last_error(o->link), o->link_backoff_ms / 1000);
                sh_link_down(*o);
            } else {
                SH_LOG("split: card %s:%d live with %zu weight slices (%.0f ms)\n", o->host.c_str(), o->port,
                       o->weights.size(), sh_now_ms() - t0);
                o->link_backoff_ms = 1000;
            }
            o->dirty = false;
        }
    }

    std::vector<char> &done = s.done;
    done.assign((size_t)n, 0);
    {
        int64_t widest = 0;
        for (int i = 0; i < n; i++) {
            const ggml_tensor *nd = ggml_graph_node(cgraph, i);
            if (nd->op == GGML_OP_MUL_MAT && nd->src[1] && nd->src[1]->ne[1] > widest) widest = nd->src[1]->ne[1];
        }
        if (widest > 0) s.graph_w[widest <= 1 ? 0 : widest <= 4 ? 1 : widest <= 8 ? 2 : 3]++;
    }
    std::unordered_map<const ggml_tensor *, int> idx_of;   /* only the overlap pilot uses it */
    /* `done` means SCHEDULED, not produced: the gathering loop marks the whole
     * activation group done BEFORE the exchange is issued, so a node marked
     * done may still be in flight. The overlap pilot's first version read
     * `done` as "produced and verified" and therefore selected work that reads
     * a product still on the wire -- which is what its batch at node 0 of warm
     * prefill actually was. `produced` is set only after an output has been
     * written and, for offloaded nodes, only after the exchange returned
     * SH_OK and the post step reconstructed the result. */
    std::vector<char> produced;
    if (sh_overlap_cpu_enabled()) {          /* eagerly: a lazily built map would
                                              * miss everything produced before the
                                              * first eligible exchange */
        produced.assign((size_t)n, 0);       /* unused when overlap is disabled */
        idx_of.reserve((size_t)n * 2);
        for (int q = 0; q < n; q++) idx_of[ggml_graph_node(cgraph, q)] = q;
    }
    auto mark_produced = [&](const ggml_tensor *t) {
        auto f = idx_of.find(t);
        if (f != idx_of.end()) produced[f->second] = 1;
    };
    for (int i = 0; i < n; i++) {
        if (done[i]) continue;
        ggml_tensor *node = ggml_graph_node(cgraph, i);
        if (sh_is_meta(node)) continue;
        if (node->op != GGML_OP_MUL_MAT) {
            sh_fusion_pattern pattern;
            if (sh_local_island_pattern(node, pattern)) {
                if (!sh_compute_local_island(s, node, pattern)) return GGML_STATUS_FAILED;
                done[i] = 1;
                if (!idx_of.empty()) produced[i] = 1;
                continue;
            }
            fprintf(stderr, "[shielded] refusing an op we never claimed (%s); failing the graph\n", ggml_op_name(node->op));
            return GGML_STATUS_FAILED;
        }
        const ggml_tensor *a = node->src[1];
        auto it = s.weights.find(ggml_get_name(node->src[0]));
        if (it == s.weights.end()) {
            if (g_weight_verifier) {
                fprintf(stderr, "[shielded] %s: no authenticated registered weight; refusing source fallback\n", ggml_get_name(node->src[0]));
                return GGML_STATUS_FAILED;
            }
            // We claimed it in supports_op and then failed to register it. Compute
            // it honestly rather than killing the graph, and say so once.
            static std::set<std::string> told;
            const std::string nm = ggml_get_name(node->src[0]);
            if (told.insert(nm).second)
                fprintf(stderr, "[shielded] %s: claimed but not registered; computing it "
                                "in the enclave (nothing offloaded for this site)\n", nm.c_str());
            sh_plain_mul_mat(node->src[0], a, node);
            s.local_nodes++; done[i] = 1; if (!idx_of.empty()) produced[i] = 1;
            continue;
        }

        /* Gather every later matmul in this split that reads the SAME activation
         * and belongs to the same group: gate with up, q with k and v. They are
         * one exchange under one pad. */
        std::vector<ggml_tensor *> &members = s.members;
        std::vector<sh_state::entry *> &ents = s.ents;
        members.clear(); ents.clear();
        members.push_back(node); ents.push_back(&it->second);
        for (int j = i + 1; j < n && members.size() < SH_GROUP_MAX; j++) {
            ggml_tensor *o = ggml_graph_node(cgraph, j);
            if (done[j] || sh_is_meta(o)) continue;
            if (o->op != GGML_OP_MUL_MAT || o->src[1] != a) continue;
            auto jt = s.weights.find(ggml_get_name(o->src[0]));
            if (jt == s.weights.end() || jt->second.group != it->second.group) continue;
            members.push_back(o); ents.push_back(&jt->second); done[j] = 1;
        }
        done[i] = 1;

        const sh_state::entry &e0 = *ents[0];
        const int64_t K = e0.K;
        if (a->ne[1] < 0 || a->ne[1] > INT32_MAX) return GGML_STATUS_FAILED;
        const int32_t m = (int32_t)a->ne[1];
        trace_m = (int)m;
        /* A zero-row matmul has a zero-element output and nothing to exchange.
         * The MTP head context issues one against the tied lm_head; sending it
         * was refused as m outside [1,max_m] and, worse, that refusal used to
         * mark the link dead for the rest of the process. */
        if (m == 0) continue;

        /* x_field = round(x * 2^af), with the outlier channels held back. The
         * exponent is a public model constant; deriving it from the activation in
         * hand would buy field headroom by leaking activation magnitude. */
        const double te0 = sh_now_ms();
        std::vector<int64_t> &x_gpu = s.x_gpu, &x_tee = s.x_tee;
        if (x_gpu.size() < (size_t)m * K) x_gpu.resize((size_t)m * K);
        /* Also a pure map over m*K, on the same serialized thread as the
         * mask; SHIELDED_FIELD_THREADS spreads it (width 1 = one call). */
        struct sh_enc_range {
            const sh_simd *simd; const float *src; float scale, limit; int64_t *dst;
            std::atomic<int> bad, wide;
        } er = { simd, (const float *)a->data, e0.act_scale, e0.encode_limit, x_gpu.data(), {0}, {0} };
        sh_par_for((int64_t)m * K, 1024, [](void *ctx, int64_t lo, int64_t hi) {
            auto *e = (sh_enc_range *)ctx;
            /* Use the encoder's existing comparisons to prove the link's
             * individual-value bound, avoiding another full scan when every
             * activation fits that bound. A chunk that needs
             * the wider local range is re-encoded in full, then checked below
             * after the local outlier channels have been removed. */
            if (!e->simd->encode_checked(e->src + lo, (size_t)(hi - lo), e->scale,
                                        (float)SH_FV_X_LIMIT, e->dst + lo)) {
                if (e->limit <= (float)SH_FV_X_LIMIT ||
                    !e->simd->encode_checked(e->src + lo, (size_t)(hi - lo), e->scale, e->limit, e->dst + lo))
                    e->bad.store(1, std::memory_order_relaxed);
                else e->wide.store(1, std::memory_order_relaxed);
            }
        }, &er);
        if (er.bad.load(std::memory_order_relaxed)) {
            fprintf(stderr, "[shielded] %s: nonfinite or unsupported activation range; aborting the graph\n", ggml_get_name(node->src[0]));
            return GGML_STATUS_FAILED;
        }
        const size_t nout = e0.site->outliers.size();
        if (nout) {
            if (x_tee.size() < (size_t)m * nout) x_tee.resize((size_t)m * nout);
            for (int32_t r = 0; r < m; r++)
                for (size_t c = 0; c < nout; c++) {
                    const int64_t k = e0.site->outliers[c];
                    x_tee[(size_t)r * nout + c] = x_gpu[(size_t)r * K + k];
                    x_gpu[(size_t)r * K + k] = 0;
                }
            /* Encoding allowed the wider local-outlier range. Reject an
             * oversized ordinary lane before consuming pads or exchanging.
             * The link's defensive range refusal is SH_ERR_VERIFY, which
             * the backend must otherwise treat as a permanent integrity
             * failure. Invalid caller input must not retire trusted state. */
            if (er.wide.load(std::memory_order_relaxed) &&
                !simd->values_within(x_gpu.data(), (size_t)m * K, SH_FV_X_LIMIT)) {
                fprintf(stderr, "[shielded] %s: unsupported non-outlier activation range; aborting the graph\n", ggml_get_name(node->src[0]));
                return GGML_STATUS_FAILED;
            }
        }
        s.t_encode += sh_now_ms() - te0;

        /* The exchange set. Normally the visible members; when the group has
         * members this split cannot see (see group_members), either the whole
         * group is exchanged now and the rest cached, or the visible members
         * are served from the cache an earlier split filled for this very
         * activation. The cache is keyed on the exact field-encoded x that
         * crossed (outliers already held back): a match means the worker would
         * return the identical product, so it is not asked again. */
        const bool live = s.link && !s.link_failed && sh_link_is_live(s.link);
        /* In the enclave, on the CPU backend: a contended card (all but the
         * probe group, which keeps measuring it) or a link that is down,
         * unless the exact int64 path was asked for. */
        if (!g_weight_verifier && ((s.contention.contended && e0.group != s.probe_group) || (!live && !sh_local_exact()))) {
            bool ok = true;
            for (size_t t = 0; t < members.size() && ok; t++) ok = sh_cpu_compute(members[t]);
            if (ok) { s.local_nodes += members.size(); continue; }
            /* no CPU backend to be had: fall through to the paths below */
        }
        std::vector<sh_state::entry *> &xents = s.xents;
        xents.clear();
        const std::vector<std::string> &gm = s.group_members[e0.group];
        sh_state::gcache *gc = nullptr;
        bool served = false;
        if (live && gm.size() > members.size()) {
            gc = &s.completion[e0.group];
            if (gc->m == m && gc->x.size() == (size_t)m * K &&
                memcmp(gc->x.data(), x_gpu.data(), (size_t)m * K * sizeof(int64_t)) == 0) {
                served = true;
                for (size_t t = 0; t < ents.size() && served; t++) served = gc->y.count(ents[t]->name) > 0;
            }
            if (!served) for (const std::string &nm : gm) xents.push_back(&s.weights[nm]);
        }
        if (xents.empty()) xents = ents;          /* served, or no invisible members: the visible set */

        /* One flat y buffer for the exchange set; yp[t] is member t's rows within it. */
        std::vector<int64_t *> &yp = s.yp;
        std::vector<int> &nodes = s.nodes;
        yp.resize(xents.size()); nodes.resize(xents.size());
        size_t ytot = 0;
        for (size_t t = 0; t < xents.size(); t++) ytot += (size_t)m * xents[t]->N;
        if (s.ys.size() < ytot) s.ys.resize(ytot);
        for (size_t t = 0, off = 0; t < xents.size(); t++) {
            yp[t] = s.ys.data() + off; nodes[t] = xents[t]->node;
            off += (size_t)m * xents[t]->N;
        }
        const double tl0 = sh_now_ms();
        int rc;
        bool split_post_done = false;   /* the cards' workers already descaled their columns */
        if (served) {
            /* Copied out rather than pointed at: the post-processing below
             * adds the outlier term in place, and a member may be served again
             * if ggml asks for it twice. */
            for (size_t t = 0; t < xents.size(); t++) {
                const std::vector<int64_t> &src = gc->y[xents[t]->name];
                memcpy(yp[t], src.data(), src.size() * sizeof(int64_t));
            }
            rc = SH_OK;
            s.offloaded_nodes += members.size(); s.served += members.size();
        } else if (live && !xents.empty() && xents[0]->part_cards.size() > 1) {
            sh_pool &pool = sh_pool_get();
            bool all_live = true;
            for (int ci : xents[0]->part_cards) {
                sh_state *card = pool.cards[ci];
                if (!card->link || card->link_failed || !sh_link_is_live(card->link)) all_live = false;
            }
            sh_split_post post;
            post.simd = simd; post.x_tee = x_tee.data(); post.nout = nout; post.m = m;
            for (size_t t = 0; t < members.size(); t++) {
                const sh_state::entry &e = *ents[t];
                size_t xi = 0;
                while (xi < xents.size() && xents[xi] != ents[t]) xi++;
                /* The slice post reads the FULL-WIDTH descale and outlier
                 * tables, which only the card owning column 0 keeps. If either
                 * is not full width, fall back to the ordinary post loop
                 * rather than index a short table. */
                if (xi >= xents.size() || e.inv.size() != (size_t)e.N ||
                    e.out_cols.size() != nout * (size_t)e.N) { post.y.clear(); break; }
                post.y.push_back(yp[xi]);
                post.xi.push_back(xi);
                post.dst.push_back((float *)members[t]->data);
                post.inv.push_back(e.inv.data());
                post.out_cols.push_back(e.out_cols.data());
                post.N.push_back(e.N);
            }
            static const bool no_slice_post = sh_env_int("SHIELDED_SPLIT_NOPOST", 0) != 0;
            const bool post_ok = !no_slice_post && post.y.size() == members.size();
            /* PILOT: fill this exchange's idle window with islands whose
             * matmul is already computed. Eligibility is checked here, in
             * graph order, where `done` says exactly what has been produced. */
            sh_idle_batch idle; idle.st = &s;
            if (sh_overlap_cpu_enabled() && all_live) {
                /* Index map, built once for the graph. The first version
                 * scanned the node array for every candidate and every tensor
                 * it reads -- O(n^2) per exchange, which on a 3799-node graph
                 * over 321 exchanges is tens of billions of comparisons and
                 * killed the run before a single island was scheduled. An
                 * eligibility test that costs more than the work it schedules
                 * is not an optimisation. */
                for (int j = i + 1; j < n; j++) {
                    if (done[j]) continue;
                    ggml_tensor *nj = ggml_graph_node(cgraph, j);
                    if (sh_is_meta(nj) || nj->op == GGML_OP_MUL_MAT) continue;
                    sh_fusion_pattern pat;
                    if (!sh_local_island_pattern(nj, pat)) continue;
                    s.sel_pattern++;
                    /* EVERY tensor the island reads must already be produced,
                     * not just the matmul it fuses. The first version checked
                     * pat.first alone and the graph failed closed on warm
                     * prefill, because the residual side of the add can be
                     * produced by a node this split has not reached. A pointer
                     * edge says what is read; it does not say it is ready. */
                    const ggml_tensor *reads[] = { pat.first, pat.residual, pat.add, pat.norm, pat.scaled };
                    /* The predicate lives in shielded-overlap.h and is tested
                     * directly (test/shielded-overlap-ready.test.mjs). The real
                     * graph never presents a positive case, so this branch is
                     * exercised nowhere else. */
                    struct ready_ctx { std::unordered_map<const ggml_tensor *, int> *idx;
                                       std::vector<char> *prod;
                                       std::vector<ggml_tensor *> *live; } rc_ctx{ &idx_of, &produced, &members };
                    sh_ready_ops rops;
                    rops.ctx = &rc_ctx;
                    rops.index_of = [](const ggml_tensor *t, void *c) -> int {
                        auto *x = (ready_ctx *)c; auto f = x->idx->find(t);
                        return f == x->idx->end() ? -1 : f->second; };
                    rops.is_produced = [](int i, void *c) -> bool {
                        auto *x = (ready_ctx *)c; return i >= 0 && (size_t)i < x->prod->size() && (*x->prod)[i]; };
                    rops.is_in_flight = [](const ggml_tensor *t, void *c) -> bool {
                        auto *x = (ready_ctx *)c;
                        for (auto *mv : *x->live)
                            for (const ggml_tensor *w = mv; w; w = w->view_src) if (w == t) return true;
                        return false; };
                    const sh_ready_result rr = sh_island_ready(reads, 5, nj, &rops);
                    /* Both facts, counted independently. The previous counters
                     * shared one loop with an early break, so an in-flight
                     * matmul -- which is always also unproduced -- could only
                     * ever be recorded as not-ready, and "in-flight=0" was an
                     * artifact of the test order rather than a finding. */
                    if (rr.depends_on_in_flight) s.sel_inflight++;
                    if (rr.depends_on_unproduced) s.sel_notready++;
                    const bool ready = rr.ready;
                    if (!ready) continue;
                    /* Dependencies are not enough. ggml's allocator reuses
                     * tensor memory on the assumption that nodes run in graph
                     * order, so a node moved earlier can write into a range
                     * that is still live for something else -- in particular
                     * for an output this very exchange is about to fill.
                     * Refuse anything whose bytes overlap a y this exchange
                     * writes. Necessary, and NOT sufficient: a third tensor
                     * could be live in that range and the allocator does not
                     * expose its liveness. */
                    bool aliases = false;
                    const char *nb = (const char *)nj->data;
                    const char *ne_ = nb + ggml_nbytes(nj);
                    for (size_t t = 0; t < members.size() && !aliases; t++) {
                        const char *yb = (const char *)members[t]->data;
                        if (!yb || !nb) continue;
                        if (nb < yb + ggml_nbytes(members[t]) && yb < ne_) aliases = true;
                    }
                    if (aliases) { s.sel_alias++; continue; }
                    s.sel_taken++;
                    idle.items.emplace_back(nj, pat);
                }
                if (!idle.items.empty()) {
                    static int shout = 0;
                    if (shout < 3) { shout++; fprintf(stderr, "[shielded] pilot: batch=%zu at node %d m=%d\n", idle.items.size(), i, (int)m); }
                    sh_link_set_idle_work(s.link, sh_idle_run, &idle);
                }
            }
            rc = all_live ? sh_split_exchange(pool, xents, yp, x_gpu.data(), m, post_ok ? &post : nullptr) : SH_ERR_IO;
            /* Unlike a shape refusal, a broken transport must re-enter the
             * start path. Otherwise column splitting silently stays on the
             * whole-model CPU fallback forever after the broker goes idle.
             * Both split threads have joined here. Reconnect once and retry
             * this still-uncommitted product with fresh pads. A verifier
             * failure is never eligible for this recovery. */
            if (rc == SH_ERR_IO || rc == SH_ERR_VIOLATION) {
                bool recovered = true;
                for (int ci : xents[0]->part_cards) {
                    sh_state *card = pool.cards[ci];
                    std::unique_lock<std::mutex> card_lock(card->mu, std::defer_lock);
                    if (card != &s) card_lock.lock();
                    if (sh_card_integrity_failed(*card)) {
                        rc = SH_ERR_VERIFY; recovered = false; break;
                    }
                    if (!card->link) { recovered = false; break; }
                    const int start_rc = sh_link_start(card->link);
                    if (start_rc != SH_OK) {
                        sh_link_down(*card);
                        recovered = false;
                        if (start_rc == SH_ERR_VERIFY) { rc = SH_ERR_VERIFY; break; }
                    } else {
                        card->dirty = false;
                        card->link_failed = false;
                        card->link_backoff_ms = 1000;
                    }
                }
                if (recovered) rc = sh_split_exchange(pool, xents, yp, x_gpu.data(), m, post_ok ? &post : nullptr);
                if (rc != SH_OK && rc != SH_ERR_VERIFY) {
                    for (int ci : xents[0]->part_cards) {
                        sh_state *card = pool.cards[ci];
                        std::unique_lock<std::mutex> card_lock(card->mu, std::defer_lock);
                        if (card != &s) card_lock.lock();
                        sh_link_down(*card);
                    }
                    sh_link_set_idle_work(s.link, nullptr, nullptr);
                    fprintf(stderr, "[shielded] split transport recovery failed; refusing a silent CPU downgrade\n");
                    return GGML_STATUS_FAILED;
                }
            }
            if (!idle.items.empty()) {
                sh_link_set_idle_work(s.link, nullptr, nullptr);
                /* Mark only what actually completed. A pilot must not be able
                 * to fail the graph: if an island did not compute, it is left
                 * for the main loop to do in its normal place, which is the
                 * behaviour with the pilot switched off. */
                for (size_t k = 0; k < idle.done_n; k++) {
                    auto f = idx_of.find(idle.items[k].first);
                    if (f != idx_of.end()) { done[f->second] = 1; produced[f->second] = 1; }
                }
            }
            split_post_done = post_ok && rc == SH_OK;
            if (rc == SH_ERR_VERIFY) {
                s.verify_fail++;
                for (int ci : xents[0]->part_cards) {
                    sh_state *card = pool.cards[ci];
                    fprintf(stderr, "[shielded] split verify: card %d %s:%d says: %s\n", ci, card->host.c_str(), card->port,
                            card->link ? sh_link_last_error(card->link) : "(no link)");
                }
                /* Recompute each card's slice in the enclave and check THAT:
                 * a local product that also fails names the check vectors, one
                 * that passes names the worker's copy of the weights. */
                for (size_t c = 0; c < xents[0]->part_cards.size(); c++) {
                    sh_state *card = pool.cards[xents[0]->part_cards[c]];
                    const int nid = xents[0]->part_nodes[c];
                    const int64_t nc = (c + 1 < xents[0]->part_col0.size() ? xents[0]->part_col0[c + 1] : xents[0]->N) - xents[0]->part_col0[c];
                    std::vector<int64_t> scratch((size_t)m * nc, 0);
                    int64_t *sp = scratch.data();
                    const int lrc = sh_link_gemm_local(card->link, &nid, 1, x_gpu.data(), m, &sp);
                    /* The log is host-visible and a worker can reach this path
                     * at will: NO product value is printed, ever. Whether the
                     * LOCAL product passes the check depends on the activations
                     * (it fails only when the true product leaves the field), so
                     * that bit is printed only under the development opt-in. */
                    if (sh_fault_diag_plaintext()) {
                        const bool ok = lrc == SH_OK && sh_link_verify(card->link, nid, x_gpu.data(), scratch.data(), m);
                        fprintf(stderr, "[shielded] split probe: card %zu node %d cols %lld..%lld local rc=%d [plaintext opt-in: local verify=%d]\n",
                                c, nid, (long long)xents[0]->part_col0[c], (long long)(xents[0]->part_col0[c] + nc), lrc, (int)ok);
                    } else {
                        fprintf(stderr, "[shielded] split probe: card %zu node %d cols %lld..%lld local rc=%d\n",
                                c, nid, (long long)xents[0]->part_col0[c], (long long)(xents[0]->part_col0[c] + nc), lrc);
                    }
                }
                fprintf(stderr, "[shielded] split verify: group %s m=%d members=%zu xents=%zu K=%lld\n",
                        e0.group.c_str(), (int)m, members.size(), xents.size(), (long long)K);
                for (size_t t = 0; t < xents.size(); t++)
                    fprintf(stderr, "[shielded]   member %s N=%lld cols:%lld+%lld / %lld+%lld\n", xents[t]->name.c_str(),
                            (long long)xents[t]->N, (long long)xents[t]->part_col0[0],
                            (long long)(xents[t]->part_col0.size() > 1 ? xents[t]->part_col0[1] - xents[t]->part_col0[0] : 0),
                            (long long)(xents[t]->part_col0.size() > 1 ? xents[t]->part_col0[1] : 0),
                            (long long)(xents[t]->part_col0.size() > 1 ? xents[t]->N - xents[t]->part_col0[1] : 0));
                return GGML_STATUS_FAILED;
            }
            if (rc != SH_OK && g_weight_verifier) {
                rc = sh_local_products(s, nodes, xents, x_gpu.data(), m, yp.data());
                s.local_nodes += members.size();
            } else if (rc != SH_OK) {
                /* A card that is not live cannot produce its columns, and this
                 * card's own nodes are only a SLICE of each weight -- so the
                 * local fallback is the whole-tensor one, straight from the
                 * public ggml weights, not this link's products. */
                static bool told = false;
                if (!told) {
                    told = true;
                    fprintf(stderr, "[shielded] split exchange unavailable (rc %d, all_live %d); computing in the enclave\n", rc, (int)all_live);
                    for (int ci : xents[0]->part_cards) {
                        sh_state *card = pool.cards[ci];
                        fprintf(stderr, "[shielded]   card %d %s:%d link=%p failed=%d live=%d\n", ci, card->host.c_str(), card->port,
                                (void *)card->link, (int)card->link_failed, (int)(card->link && sh_link_is_live(card->link)));
                    }
                }
                for (size_t t = 0; t < members.size(); t++) sh_plain_mul_mat(members[t]->src[0], a, members[t]);
                s.local_nodes += members.size();
                s.t_link += sh_now_ms() - tl0;
                continue;
            } else {
                s.offloaded_nodes += members.size(); s.exchanges++;
                s.m_hist[m < 1 ? 0 : m > 9 ? 9 : m]++;
                if (xents.size() > members.size()) {
                    s.completed++;
                    gc->m = m;
                    gc->x.assign(x_gpu.begin(), x_gpu.begin() + (size_t)m * K);
                    gc->y.clear();
                    for (size_t t = 0; t < xents.size(); t++) {
                        bool visible = false;
                        for (size_t v = 0; v < ents.size(); v++) visible = visible || ents[v] == xents[t];
                        if (!visible) gc->y[xents[t]->name].assign(yp[t], yp[t] + (size_t)m * xents[t]->N);
                    }
                }
            }
        } else if (live) {
            rc = sh_link_gemm(s.link, nodes.data(), nodes.size(), x_gpu.data(), m, yp.data());
            if (rc == SH_ERR_VERIFY) {
                /* A corrupted product must never reach the caller: it would be
                 * sampled, streamed, or written into the KV cache, where one bad
                 * entry poisons every future token that attends to it. */
                s.verify_fail++;
                fprintf(stderr, "[shielded] %s\n", sh_link_last_error(s.link));
                return GGML_STATUS_FAILED;
            }
            if (rc == SH_ERR_EXHAUST && sh_link_is_dealt(s.link)) {
                /* Dealt pads and the bank is behind: the trusted half has
                 * nothing to mask with and must not silently fall back to
                 * computing everything in the clear at a tenth of the speed
                 * (shielded/dealer/PLAN.md: "refuses to proceed on pad
                 * exhaustion"). The request fails loudly; the next one retries. */
                fprintf(stderr, "[shielded] %s: %s; refusing to proceed without dealt pads\n", ggml_get_name(node->src[0]), sh_link_last_error(s.link));
                return GGML_STATUS_FAILED;
            }
            if (rc != SH_OK) {
                /* Two different failures. A transport error (socket died, or
                 * the worker refused the frame and closed) takes the link down
                 * until the retry fires. A bookkeeping refusal from our own
                 * link (SH_ERR_PROTO: m outside the group's range, a node set
                 * that does not share a group) is a property of THIS node, not
                 * of the connection -- it is computed here and the link stays
                 * up. Conflating the two once turned one odd matmul into a
                 * permanent 15x slowdown. */
                if (rc == SH_ERR_PROTO) {
                    static std::set<std::string> told;
                    const std::string nm = ggml_get_name(node->src[0]);
                    if (told.insert(nm).second)
                        fprintf(stderr, "[shielded] %s: not offloadable as shaped (%s); computing it in the enclave\n",
                                nm.c_str(), sh_link_last_error(s.link));
                } else {
                    fprintf(stderr, "[shielded] %s: offload failed (%s); computing in the enclave, retrying the worker in %.0f s\n",
                            ggml_get_name(node->src[0]), sh_link_last_error(s.link), s.link_backoff_ms / 1000);
                    sh_link_down(s);
                }
                rc = sh_local_products(s, nodes, xents, x_gpu.data(), m, yp.data());
                s.local_nodes += members.size();
            } else {
                s.offloaded_nodes += members.size(); s.exchanges++;
                s.m_hist[m < 1 ? 0 : m > 9 ? 9 : m]++;
                {
                    double wb = 0; for (auto *xe : xents) wb += (double)xe->K * (double)xe->N;
                    sh_note_latency(s, e0.group, m, sh_link_last_wire_us(s.link), wb);
                }
                if (xents.size() > members.size()) {
                    /* Keep the invisible members' products for the split that
                     * asks for them, with the x they belong to. */
                    s.completed++;
                    gc->m = m;
                    gc->x.assign(x_gpu.begin(), x_gpu.begin() + (size_t)m * K);
                    gc->y.clear();
                    for (size_t t = 0; t < xents.size(); t++) {
                        bool visible = false;
                        for (size_t v = 0; v < ents.size(); v++) visible = visible || ents[v] == xents[t];
                        if (!visible) gc->y[xents[t]->name].assign(yp[t], yp[t] + (size_t)m * xents[t]->N);
                    }
                }
            }
        } else {
            rc = sh_local_products(s, nodes, xents, x_gpu.data(), m, yp.data());
            s.local_nodes += members.size();
        }
        s.t_link += sh_now_ms() - tl0;
        if (rc == SH_ERR_VERIFY) {
            s.verify_fail++;
            fprintf(stderr, "[shielded] %s\n", sh_link_last_error(s.link));
            return GGML_STATUS_FAILED;
        }
        if (rc != SH_OK) {
            if (g_weight_verifier) {
                fprintf(stderr, "[shielded] %s: authenticated execution failed (%d); refusing source fallback\n", ggml_get_name(node->src[0]), rc);
                return GGML_STATUS_FAILED;
            }
            // Not a verification failure (that returned above) -- a transport or
            // bookkeeping problem. The honest answer is still available locally.
            fprintf(stderr, "[shielded] %s: offload and local path both failed (%d); "
                            "computing it in the enclave\n", ggml_get_name(node->src[0]), rc);
            for (size_t t = 0; t < members.size(); t++) sh_plain_mul_mat(members[t]->src[0], a, members[t]);
            s.local_nodes += members.size();
            continue;
        }

        const double tp0 = sh_now_ms();
        for (size_t t = 0; split_post_done && t < members.size(); t++)
            s.macs += (uint64_t)m * (uint64_t)K * (uint64_t)ents[t]->N;
        for (size_t t = 0; !split_post_done && t < members.size(); t++) {
            const sh_state::entry &e = *ents[t];
            const int64_t N = e.N;
            float *dst = (float *)members[t]->data;
            size_t xi = 0;
            while (xi < xents.size() && xents[xi] != ents[t]) xi++;
            for (int32_t r = 0; r < m; r++) {
                int64_t *yr = yp[xi] + (size_t)r * N;
                /* The outlier term, in the TEE, outside the field. */
                if (nout) simd->outlier_add(x_tee.data() + (size_t)r * nout, e.out_cols.data(), (int)nout, N, yr);
                /* Per-column descale: each output column carries its own exponent,
                 * which is what stops one outlier weight quantising a whole tensor
                 * to nothing. */
                simd->descale(yr, e.inv.data(), (size_t)N, dst + (size_t)r * N);
            }
            s.macs += (uint64_t)m * (uint64_t)K * (uint64_t)N;
        }
        s.t_post += sh_now_ms() - tp0;
        /* Outputs now exist and, for the offloaded path, have passed Freivalds
         * and been reconstructed. Only here does a member become readable by
         * anything the pilot may schedule. */
        if (!idx_of.empty())
            for (size_t t = 0; t < members.size(); t++) mark_produced(members[t]);
    }
    s.t_graph += sh_now_ms() - tg0;
    /* SHIELDED_PHASE_TRACE=1: one CUMULATIVE record per graph_compute call.
     * Cumulative on purpose -- differencing two records gives an exact window
     * with no reset to reason about, which is what the per-pipe counters got
     * wrong. Every field is inclusive of everything before it in this process,
     * and the units are stated in the header so a reader does not have to
     * infer whether a figure is per pass, per token or per card.
     *   m        rows in THIS graph (1 = plain decode, k+1 = a verify pass)
     *   nodes    offloaded nodes so far, this card
     *   ex       exchanges so far, this card
     *   idle     ms of post-RHS spin so far, this card
     *   link     ms inside the exchange path so far, this card
     *   graph    ms inside this backend's graph_compute so far, this card */
    if (sh_phase_trace()) {
        /* Recorded, not printed. The first version called fprintf here, inside
         * the wall time the benchmark measures, so the residual it was used to
         * compute included its own trace I/O. Appending to a reserved vector is
         * a few stores; the file is written once at exit. */
        sh_link_profile lp{}; sh_link_profile_snapshot(s.link, &lp);
        sh_trace_push(s.card_index, sh_now_ms(), trace_m, s.graph_calls,
                      s.offloaded_nodes, s.exchanges, lp.idle_ms, s.t_link, s.t_graph,
                      lp.mask_ms, lp.unmask_lhs_ms, lp.rhs_ms, lp.check_ms, lp.pads_ms, lp.wire_ms, lp.pre_ms,
                      s.t_split_gemm, s.t_split_post, s.t_split_join, sh_split_helper_gemm(), sh_split_helper_post(),
                      lp.mask_kernel_ms, lp.dealt_wait_ms,
                      lp.mask_elems, lp.mask_slow_n, lp.mask_slow_ms);
    }
    /* Under SHIELDED_PROFILE, say the per-term totals periodically as well as
     * at the end: the engine inside a CVM never calls the stats entry point,
     * and the tenant's stderr (the owner's /logs) is the only channel out of
     * the guest. Counters only -- never a value that crossed or was masked. */
    if (s.contention.contended) s.contended_graphs++;
    return GGML_STATUS_SUCCESS;
}

static enum ggml_status ggml_backend_shielded_graph_compute(ggml_backend_t, ggml_cgraph *graph) {
    sh_pool &p = sh_pool_get();
    std::unique_lock<std::mutex> lk(p.mu);
    // Prior CPU split is complete. Its workers otherwise poll while this
    // synchronous backend handles registration, pad availability and sockets.
    if (p.cpu_idle_hook) p.cpu_idle_hook(p.cpu_idle_ctx);
    sh_pool_init(p);
    /* Retire the whole multi-card backend before planning or touching another
     * graph. This pool lives for the process: an integrity failure requires
     * restarting the trusted engine, not a transport reconnect or a retry of
     * llama_decode with the old contexts and secret verification vectors. */
    for (auto *s : p.cards) {
        std::lock_guard<std::mutex> card_lock(s->mu);
        if (sh_card_integrity_failed(*s)) return GGML_STATUS_FAILED;
    }
    // Direct backend callers do not necessarily run supports_op first.
    for (int i = 0; i < graph->n_nodes; i++) {
        const auto *node = graph->nodes[i];
        if (node->op != GGML_OP_MUL_MAT || !node->src[0] || !node->src[0]->data) continue;
        const auto *w = node->src[0];
        const char *name = ggml_get_name(w);
        int owner = sh_owner(p, w);
        if (!p.invalid && sh_source_type_ok(w->type) && sh_source_geometry_ok(w->type, w->ne[0]) &&
            sh_site_for(*p.cards[0], name) &&
            !p.owners.count(sh_group_key(name))) p.pending[name] = *w;
        else if (!p.invalid && owner >= 0 && !p.cards[owner]->weights.count(name) && !p.cards[owner]->refused.count(name))
            p.pending[name] = *w;
    }
    sh_plan(p);
    for (const auto *s : p.cards) if (s->weight_cache_failed || s->source_verification_failed) return GGML_STATUS_FAILED;
    // Preserve dependency order. Each contiguous run belongs to one link;
    // completion caches still combine q/k/v or gate/up across scheduler splits.
    for (int i = 0; i < graph->n_nodes;) {
        auto *node = graph->nodes[i];
        if (sh_is_meta(node)) { i++; continue; }
        sh_fusion_pattern local_pattern;
        const bool local_island = node->op != GGML_OP_MUL_MAT && sh_local_island_pattern(node, local_pattern);
        if (node->op != GGML_OP_MUL_MAT && !local_island) return GGML_STATUS_FAILED;
        const int owner = sh_graph_node_owner(p, node);
        if (p.invalid || owner < 0) {
            if (local_island) {
                if (!sh_compute_local_island(*p.cards[0], node, local_pattern)) return GGML_STATUS_FAILED;
                i++; continue;
            }
            if (g_weight_verifier) {
                fprintf(stderr, "[shielded] no authenticated owner for %s; refusing source fallback\n", ggml_get_name(node->src[0]));
                return GGML_STATUS_FAILED;
            }
            sh_plain_mul_mat(node->src[0], node->src[1], node);
            p.cards[0]->local_nodes++; i++; continue;
        }
        int end = i + 1;
        while (end < graph->n_nodes) {
            const auto *next = graph->nodes[end];
            if (!sh_is_meta(next) && sh_graph_node_owner(p, next) != owner) break;
            end++;
        }
        ggml_cgraph view = {};
        view.n_nodes = view.size = end - i;
        view.nodes = graph->nodes + i;
        view.order = graph->order;
        auto rc = sh_card_compute(*p.cards[owner], &view);
        if (rc != GGML_STATUS_SUCCESS) return rc;
        i = end;
    }
    if (getenv("SHIELDED_PROFILE")) {
        static uint64_t last = 0;
        uint64_t exchanges = 0;
        for (auto *s : p.cards) exchanges += s->exchanges;
        if (exchanges - last >= 4096) {
            last = exchanges;
            lk.unlock();
            ggml_backend_shielded_stats(nullptr, nullptr, nullptr, nullptr);
        }
    }
    return GGML_STATUS_SUCCESS;
}

static const struct ggml_backend_i ggml_backend_shielded_i = {
    /* .get_name            = */ ggml_backend_shielded_get_name,
    /* .free                = */ ggml_backend_shielded_free,
    /* .set_tensor_async    = */ NULL,
    /* .get_tensor_async    = */ NULL,
    /* .set_tensor_2d_async = */ NULL,
    /* .get_tensor_2d_async = */ NULL,
    /* .cpy_tensor_async    = */ NULL,
    /* .synchronize         = */ NULL,
    /* .graph_plan_create   = */ NULL,
    /* .graph_plan_free     = */ NULL,
    /* .graph_plan_update   = */ NULL,
    /* .graph_plan_compute  = */ NULL,
    /* .graph_compute       = */ ggml_backend_shielded_graph_compute,
    /* .event_record        = */ NULL,
    /* .event_wait          = */ NULL,
    /* .graph_optimize      = */ NULL,
};

static ggml_guid_t ggml_backend_shielded_guid(void) {
    static ggml_guid guid = { 0x51, 0x48, 0x1e, 0x1d, 0x22, 0x0b, 0x4c, 0x77,
                              0x9a, 0x3e, 0x6f, 0x14, 0xd0, 0x8b, 0x2a, 0x63 };
    return &guid;
}

bool ggml_backend_is_shielded(ggml_backend_t backend) {
    return backend != NULL && ggml_guid_matches(backend->guid, ggml_backend_shielded_guid());
}

/* --- device ------------------------------------------------------------- */
static const char *sh_dev_get_name(ggml_backend_dev_t) { return "Shielded"; }
static const char *sh_dev_get_description(ggml_backend_dev_t) {
    return "masked offload to an untrusted GPU";
}
static void sh_dev_get_memory(ggml_backend_dev_t, size_t *free, size_t *total) {
    *free = *total = 0;   /* the activations live in host memory, inside the CVM */
}
static enum ggml_backend_dev_type sh_dev_get_type(ggml_backend_dev_t) {
    /* ACCEL, not GPU: the card is real but it is not inside the enclave, and the
     * distinction is the whole product. A caller enumerating GPUs must not find
     * this and conclude it has one. */
    return GGML_BACKEND_DEVICE_TYPE_ACCEL;
}
static void sh_dev_get_props(ggml_backend_dev_t dev, struct ggml_backend_dev_props *props) {
    props->name        = sh_dev_get_name(dev);
    props->description = sh_dev_get_description(dev);
    props->type        = sh_dev_get_type(dev);
    sh_dev_get_memory(dev, &props->memory_free, &props->memory_total);
    props->caps = { /* async */ false, /* host_buffer */ false,
                    /* buffer_from_host_ptr */ true, /* events */ false };
}
static ggml_backend_t sh_dev_init_backend(ggml_backend_dev_t dev, const char *) {
    ggml_backend_t backend = new ggml_backend {
        /* .guid    = */ ggml_backend_shielded_guid(),
        /* .iface   = */ ggml_backend_shielded_i,
        /* .device  = */ dev,
        /* .context = */ NULL,
    };
    { auto &p = sh_pool_get(); std::lock_guard<std::mutex> lock(p.mu); ++p.backend_refs; }
    return backend;
}
static ggml_backend_buffer_type_t sh_dev_get_buffer_type(ggml_backend_dev_t) {
    /* Host memory, like the BLAS backend. What reaches the untrusted side is
     * decided explicitly in graph_compute -- never by ggml's buffer plumbing,
     * which has no idea some of these bytes are secret. */
    return ggml_backend_cpu_buffer_type();
}
static bool sh_dev_supports_op(ggml_backend_dev_t, const struct ggml_tensor *op) {
    switch (op->op) {
        case GGML_OP_NONE: case GGML_OP_RESHAPE: case GGML_OP_VIEW:
        case GGML_OP_PERMUTE: case GGML_OP_TRANSPOSE:
            return true;
        case GGML_OP_MUL_MAT:
            return sh_claimable(op, true);
        case GGML_OP_ADD: case GGML_OP_RMS_NORM: case GGML_OP_MUL:
            return sh_local_island_claimable(op);
        default:
            return false;   /* everything nonlinear or position-aware stays in the TEE */
    }
}
static bool sh_dev_supports_buft(ggml_backend_dev_t, ggml_backend_buffer_type_t buft) {
    return buft == sh_source_buft() || ggml_backend_buft_is_host(buft);
}

static const struct ggml_backend_device_i ggml_backend_shielded_device_i = {
    /* .get_name             = */ sh_dev_get_name,
    /* .get_description      = */ sh_dev_get_description,
    /* .get_memory           = */ sh_dev_get_memory,
    /* .get_type             = */ sh_dev_get_type,
    /* .get_props            = */ sh_dev_get_props,
    /* .init_backend         = */ sh_dev_init_backend,
    /* .get_buffer_type      = */ sh_dev_get_buffer_type,
    /* .get_host_buffer_type = */ NULL,
    /* .buffer_from_host_ptr = */ NULL,
    /* .supports_op          = */ sh_dev_supports_op,
    /* .supports_buft        = */ sh_dev_supports_buft,
    /* .offload_op           = */ NULL,
    /* .event_new            = */ NULL,
    /* .event_free           = */ NULL,
    /* .event_synchronize    = */ NULL,
};

/* --- reg ---------------------------------------------------------------- */
static const char *sh_reg_get_name(ggml_backend_reg_t) { return "Shielded"; }
static size_t sh_reg_get_device_count(ggml_backend_reg_t) { return 1; }
static ggml_backend_dev_t sh_reg_get_device(ggml_backend_reg_t reg, size_t) {
    static ggml_backend_device dev = {
        /* .iface   = */ ggml_backend_shielded_device_i,
        /* .reg     = */ reg,
        /* .context = */ NULL,
    };
    return &dev;
}
static const struct ggml_backend_reg_i ggml_backend_shielded_reg_i = {
    /* .get_name         = */ sh_reg_get_name,
    /* .get_device_count = */ sh_reg_get_device_count,
    /* .get_device       = */ sh_reg_get_device,
    /* .get_proc_address = */ [](ggml_backend_reg_t, const char *name) -> void * {
        if (!strcmp(name, "ggml_backend_shielded_set_weight_verifier")) return (void *)ggml_backend_shielded_set_weight_verifier;
        if (!strcmp(name, "ggml_backend_shielded_set_source_release")) return (void *)ggml_backend_shielded_set_source_release;
        if (!strcmp(name, "ggml_backend_shielded_weight_source")) return (void *)ggml_backend_shielded_weight_source;
        if (!strcmp(name, "ggml_backend_shielded_source_candidate")) return (void *)ggml_backend_shielded_source_candidate;
        return nullptr;
    },
};

ggml_backend_reg_t ggml_backend_shielded_reg(void) {
    static ggml_backend_reg reg = {
        /* .api_version = */ GGML_BACKEND_API_VERSION,
        /* .iface       = */ ggml_backend_shielded_reg_i,
        /* .context     = */ NULL,
    };
    return &reg;
}

ggml_backend_t ggml_backend_shielded_init(void) {
    return sh_dev_init_backend(sh_reg_get_device(ggml_backend_shielded_reg(), 0), NULL);
}

/* Loadable as a module, so an engine picks the tier up as launch configuration
 * rather than a rebuild -- ggml_backend_load_all() finds it beside the binary or
 * on GGML_BACKEND_PATH. Only compiled in for the shared-library build; the static
 * one links ggml_backend_shielded_reg() directly. */
#ifdef GGML_BACKEND_DL
GGML_BACKEND_DL_IMPL(ggml_backend_shielded_reg)
#endif

/* Dealt pads: a host-supplied ledger-window provider (the pVM's owner-app
 * path), installed on every link this backend opens from now on. */
extern "C" void ggml_backend_shielded_set_window_provider(sh_window_fn fn, void *ctx) {
    g_win_fn = fn; g_win_ctx = ctx;
    sh_state &s = sh_get();
    if (s.link) sh_link_set_window_provider(s.link, fn, ctx);
}

/* The dealer's entry (shielded/dealer/PLAN.md): with the model registered on
 * the legacy single link (SHIELDED_HOST/PORT; a pool splits groups over cards
 * and a shipment must cover them all), mint one shipment. No worker is
 * needed - registration happens at context creation, before any connect. */
extern "C" int ggml_backend_shielded_mint(const char *seed_hex, const char *seed_id_hex, const char *digest_hex,
                                                           uint64_t index0, uint64_t count, const char *consumer_pk_hex, const char *path) {
    sh_state &s = sh_get();
    if (!s.link) { SH_LOG("mint: no link (set SHIELDED_HOST/PORT so the weights register)\n"); return SH_ERR_RANGE; }
    uint8_t seed[32], seed_id[16], digest[32], pk[32];
    if (!sh_pads_hex2bin(seed_hex, seed, 32) || !sh_pads_hex2bin(seed_id_hex, seed_id, 16) ||
        !sh_pads_hex2bin(digest_hex, digest, 32) || !sh_pads_hex2bin(consumer_pk_hex, pk, 32)) return SH_ERR_RANGE;
    const int rc = sh_link_mint_shipment(s.link, seed, seed_id, digest, index0, count, pk, path);
    memset(seed, 0, sizeof seed);
    return rc;
}
#ifdef SHIELDED_DEALER_MODE
extern "C" int ggml_backend_shielded_mint_worker(const char *seed_hex, const char *seed_id_hex, const char *digest_hex,
                                                                  uint64_t index0, uint64_t count, const char *consumer_pk_hex, const char *path) {
    sh_state &s = sh_get();
    if (!s.link) { SH_LOG("mint: no link\n"); return SH_ERR_RANGE; }
    uint8_t seed[32], seed_id[16], digest[32], pk[32];
    if (!sh_pads_hex2bin(seed_hex, seed, 32) || !sh_pads_hex2bin(seed_id_hex, seed_id, 16) ||
        !sh_pads_hex2bin(digest_hex, digest, 32) || !sh_pads_hex2bin(consumer_pk_hex, pk, 32)) return SH_ERR_RANGE;
    std::lock_guard<std::mutex> lk(s.mu);
    const int rc = sh_link_mint_shipment_worker(s.link, seed, seed_id, digest, index0, count, pk, path);
    if (rc != SH_OK) SH_LOG("mint via worker: %s\n", sh_link_last_error(s.link));
    memset(seed, 0, sizeof seed);
    return rc;
}
#endif
