/*
 * shielded-simd.h -- the hot loops, dispatched at run time.
 *
 * shielded-simd.c is compiled twice (AVX-512 VNNI and generic); sh_simd_get()
 * returns the table for this CPU. SHIELDED_NO_SIMD=1 forces the generic build,
 * which is also how the two are checked against each other.
 */
#ifndef SHIELDED_SIMD_H
#define SHIELDED_SIMD_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SH_FV_P2 2147483647
/* Strict activation bound for the 32-term int64 Freivalds RHS accumulators. */
#define SH_FV_X_LIMIT (INT64_C(1) << 26)

typedef struct {
    const char *name;
    void    (*pad_planes)(const int32_t *r, size_t n, uint8_t *p0, uint8_t *p1, uint8_t *p2);
    void    (*mask_planes)(const int64_t *x, const int32_t *r, size_t n, int8_t *p0, int8_t *p1, int8_t *p2);
    void    (*unmask)(const int32_t *ym, const int32_t *u, size_t n, int64_t *y);
    void    (*encode)(const float *src, size_t n, float scale, int64_t *x);
    void    (*descale)(const int64_t *y, const float *inv, size_t n, float *dst);
    int64_t (*fv_dot)(const int64_t *y, const int64_t *s, int stride, int rep, int64_t n);
    int64_t (*fv_dot_x)(const int64_t *x, const int64_t *st, int stride, int rep, int64_t n);
    void    (*fv_prepare)(const int8_t *W, int64_t K, int64_t N, const int64_t *s, int reps, int64_t *st);
    /* acc supplies at least 12*N int32 values for every batch size, including
     * the allocation-free fallback when blocked-kernel scratch is unavailable. */
    void    (*refill)(const uint8_t *planes, int b, const int8_t *W, int64_t K, int64_t N,
                      int32_t *u, int64_t u_stride, int32_t *acc);
    /* |value| < limit over an int64 range, for the activation bound checked at
     * the link boundary. Returns false if ANY value is out of range. */
    bool    (*values_within)(const int64_t *values, size_t n, uint64_t limit);
    /* Every int32 reply value inside (-M/2, M/2], checked before any kernel
     * touches the reply. A separate pass on purpose: see the note in
     * shielded-simd.c. Returns false if ANY value is out of range. */
    bool    (*reply32_balanced)(const int32_t *values, size_t n);
    void    (*outlier_add)(const int64_t *x_tee, const int8_t *wc, int nout, int64_t N, int64_t *y);
    /* The same term over a slice of the columns: `n_cols` to add, channel rows
     * `stride` apart. A column-split card adds its own slice out of the
     * full-width table. outlier_add is this with stride == n_cols. */
    void    (*outlier_add_stride)(const int64_t *x_tee, const int8_t *wc, int nout,
                                  int64_t n_cols, int64_t stride, int64_t *y);
    /* The request-path forms of the Freivalds dots. `s` and `st` are int32,
     * one contiguous row per rep ([reps][n]) rather than interleaved int64:
     * half the bytes and a unit stride, so the loop vectorises and streams.
     * All reps are produced in ONE pass over y / x, into out[reps].
     * unmask_fv is unmask fused with the lhs dot: y is written once and dotted
     * from registers instead of being re-read from memory. Measured on lm_head
     * (N=151936): verify 117 us + unmask 41 us -> see shielded-tee.c. */
    void    (*fv_dots)(const int64_t *y, const int32_t *s, int reps, int64_t n, int64_t *out);
    void    (*fv_dots_x)(const int64_t *x, const int32_t *st, int reps, int64_t n, int64_t *out);
    void    (*unmask_fv)(const int32_t *ym, const int32_t *u, const int32_t *s, int reps, int64_t n,
                         int64_t *y, int64_t *out);
    /* The same two unmasks from a FIELD_GEMM24 reply: ym is 3-byte little-
     * endian two's-complement per value (protocol 1.2). Every reply value is
     * balanced in (-M/2, M/2] with M < 2^24, so the narrow form carries the
     * identical value; these read it straight from the reply buffer, no
     * widening pass. Arithmetic after the load is unmask / unmask_fv's. */
    void    (*unmask24)(const uint8_t *ym, const int32_t *u, size_t n, int64_t *y);
    void    (*unmask24_fv)(const uint8_t *ym, const int32_t *u, const int32_t *s, int reps, int64_t n,
                           int64_t *y, int64_t *out);
    /* Checked float -> integer conversion. limit is a public power of two
     * in [2^26, 2^62]. Rejects nonfinite values/scales and |src*scale| >= limit
     * BEFORE integer conversion; a false return invalidates all scratch x. */
    int     (*encode_checked)(const float *src, size_t n, float scale, float limit, int64_t *x);
} sh_simd;

/* SHIELDED_REFILL_VECTOR_CRT=1 selects the checked AVX-512 refill epilogue
 * at first SIMD admission; all other values leave it disabled. */
const sh_simd *sh_simd_get(void);
const sh_simd *sh_simd_generic(void);

#define SH_SIMD_DECL(sfx) \
    void    sh_simd_##sfx##_pad_planes(const int32_t *, size_t, uint8_t *, uint8_t *, uint8_t *); \
    void    sh_simd_##sfx##_mask_planes(const int64_t *, const int32_t *, size_t, int8_t *, int8_t *, int8_t *); \
    void    sh_simd_##sfx##_unmask(const int32_t *, const int32_t *, size_t, int64_t *); \
    void    sh_simd_##sfx##_encode(const float *, size_t, float, int64_t *); \
    void    sh_simd_##sfx##_descale(const int64_t *, const float *, size_t, float *); \
    int64_t sh_simd_##sfx##_fv_dot(const int64_t *, const int64_t *, int, int, int64_t); \
    int64_t sh_simd_##sfx##_fv_dot_x(const int64_t *, const int64_t *, int, int, int64_t); \
    void    sh_simd_##sfx##_fv_prepare(const int8_t *, int64_t, int64_t, const int64_t *, int, int64_t *); \
    void    sh_simd_##sfx##_refill(const uint8_t *, int, const int8_t *, int64_t, int64_t, int32_t *, int64_t, int32_t *); \
    bool    sh_simd_##sfx##_values_within(const int64_t *, size_t, uint64_t); \
    bool    sh_simd_##sfx##_reply32_balanced(const int32_t *, size_t); \
    void    sh_simd_##sfx##_outlier_add(const int64_t *, const int8_t *, int, int64_t, int64_t *); \
    void    sh_simd_##sfx##_outlier_add_stride(const int64_t *, const int8_t *, int, int64_t, int64_t, int64_t *); \
    void    sh_simd_##sfx##_fv_dots(const int64_t *, const int32_t *, int, int64_t, int64_t *); \
    void    sh_simd_##sfx##_fv_dots_x(const int64_t *, const int32_t *, int, int64_t, int64_t *); \
    void    sh_simd_##sfx##_unmask_fv(const int32_t *, const int32_t *, const int32_t *, int, int64_t, int64_t *, int64_t *); \
    void    sh_simd_##sfx##_unmask24(const uint8_t *, const int32_t *, size_t, int64_t *); \
    void    sh_simd_##sfx##_unmask24_fv(const uint8_t *, const int32_t *, const int32_t *, int, int64_t, int64_t *, int64_t *); \
    int     sh_simd_##sfx##_encode_checked(const float *, size_t, float, float, int64_t *);
SH_SIMD_DECL(avx512)
/* Internal mask-bank sampler. Call only after AVX-512 admission. n must fit
 * the caller's reserved counter window; output order matches scalar ChaCha20. */
void sh_simd_avx512_mask_stream(const uint32_t key[8], uint64_t counter,
                               int32_t *out, size_t n);
void sh_simd_avx512_refill_vector_crt(const uint8_t *, int, const int8_t *,
    int64_t, int64_t, int32_t *, int64_t, int32_t *);
SH_SIMD_DECL(generic)
#if defined(__aarch64__)
/* The third build, aarch64 only (-DSH_SIMD_NEON, suffix _neon): SDOT for the
 * refill inner product, the same C body as generic for everything else. */
SH_SIMD_DECL(neon)
#ifdef SH_HAVE_NEON_TUNED
/* Optional experimental table, selected only by SHIELDED_ARM_TUNED=1. */
SH_SIMD_DECL(neon_tuned)
#endif
#endif

#ifdef __cplusplus
}
#endif
#endif
