/*! enclave-pvm-client 0.1.0 (LAB, not production) -- built by client/build.sh with esbuild 0.28.1
Contains @hpke/core 1.9.0 and @hpke/common 1.10.1 (MIT):
@hpke/core 1.9.0:
MIT License

Copyright (c) 2023 Ajitomi Daisuke

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

@hpke/common 1.10.1:
MIT License

Copyright (c) 2024 Ajitomi Daisuke

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// ../web/pvm-verify.js
var MAX_CERT = 64 * 1024;
var te = new TextEncoder();

// src/trust.js
var te2 = new TextEncoder();
var td = new TextDecoder("utf-8", { fatal: true });
var HEX = (n) => new RegExp(`^[0-9a-f]{${n}}$`);
var MAX_DOC = 64 * 1024;
function initialState({ policyKeyFp, serialFloor, releaseKeyFp }) {
  if (!HEX(64).test(policyKeyFp || "") || !HEX(64).test(releaseKeyFp || "") || !Number.isSafeInteger(serialFloor) || serialFloor < 1)
    throw new Error("the install anchor needs a policy key fingerprint, a serial floor >= 1 and a release key fingerprint");
  if (policyKeyFp === releaseKeyFp) throw new Error("the policy key and the release key must be distinct");
  return { policyFp: policyKeyFp, nextPolicyFp: null, serial: serialFloor, digest: null, releaseFp: releaseKeyFp, nextReleaseFp: null };
}

// ext/options.src.js
var $ = (id) => document.getElementById(id);
var fields = ["policyKeyFp", "serialFloor", "releaseKeyFp", "policyUrl", "relayUrl", "appId"];
async function install(v) {
  const have = await chrome.storage.local.get(["state"]);
  if (have.state) {
    $("out").textContent = "An anchor is already installed; reinstall the extension to change it.";
    return false;
  }
  const state = initialState({ policyKeyFp: v.policyKeyFp, serialFloor: Number(v.serialFloor), releaseKeyFp: v.releaseKeyFp });
  await chrome.storage.local.set({ state, config: { policyUrl: v.policyUrl, relayUrl: v.relayUrl, appId: v.appId, resultUrl: v.resultUrl || null } });
  $("out").textContent = `Installed: ${JSON.stringify(state)}`;
  if (v.resultUrl) await fetch(v.resultUrl, { method: "POST", body: JSON.stringify({ installed: true, anchor: { policyKeyFp: state.policyFp, serialFloor: state.serial, releaseKeyFp: state.releaseFp } }), credentials: "omit" }).catch(() => {
  });
  return true;
}
var q = new URLSearchParams(location.search);
if (q.get("install") === "1") install(Object.fromEntries([...fields, "resultUrl"].map((k) => [k, q.get(k)]))).catch((e) => {
  $("out").textContent = e.message;
});
$("f").addEventListener("submit", (ev) => {
  ev.preventDefault();
  install(Object.fromEntries(fields.map((k) => [k, $(k).value.trim()]))).catch((e) => {
    $("out").textContent = e.message;
  });
});
