/*! enclave-pvm-client 0.2.0 (LAB, not production) -- built by client/build.sh with esbuild 0.28.1
Contains @hpke/core 1.9.0 and @hpke/common 1.10.1 (MIT):
@hpke/core 1.9.0:
MIT License

Copyright (c) 2023 Ajitomi Daisuke

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

@hpke/common 1.10.1:
MIT License

Copyright (c) 2024 Ajitomi Daisuke

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// ../web/pvm-verify.js
var MAX_CERT = 64 * 1024;
var te = new TextEncoder();

// src/trust.js
var te2 = new TextEncoder();
var td = new TextDecoder("utf-8", { fatal: true });
var HEX = (n) => new RegExp(`^[0-9a-f]{${n}}$`);
var MAX_DOC = 64 * 1024;
function initialState({ policyKeyFp, serialFloor, releaseKeyFp }) {
  if (!HEX(64).test(policyKeyFp || "") || !HEX(64).test(releaseKeyFp || "") || !Number.isSafeInteger(serialFloor) || serialFloor < 1)
    throw new Error("the install anchor needs a policy key fingerprint, a serial floor >= 1 and a release key fingerprint");
  if (policyKeyFp === releaseKeyFp) throw new Error("the policy key and the release key must be distinct");
  return { policyFp: policyKeyFp, nextPolicyFp: null, serial: serialFloor, digest: null, releaseFp: releaseKeyFp, nextReleaseFp: null };
}

// src/store-ext.js
var StoreError = class extends Error {
};
var KEY = "stateDoc";
var LOCK = "enclave-pvm-client-state";
var canon = (v) => JSON.stringify(v, (k, x) => x && typeof x === "object" && !Array.isArray(x) ? Object.fromEntries(Object.keys(x).sort().map((y) => [y, x[y]])) : x);
var sameState = (a, b) => canon(a) === canon(b);
var ExtStore = class {
  constructor(storage = globalThis.chrome && chrome.storage && chrome.storage.local, locks = globalThis.navigator && navigator.locks) {
    if (!storage || !locks) throw new StoreError("no extension storage or Web Locks here: refusing");
    this.storage = storage;
    this.locks = locks;
  }
  async latest() {
    let got;
    try {
      got = await this.storage.get([KEY, "state"]);
    } catch (e) {
      throw new StoreError(`the extension storage is unreadable (${e.message})`);
    }
    if (got[KEY]) {
      const d = got[KEY];
      if (!Number.isSafeInteger(d.gen) || d.gen < 1 || !d.state || typeof d.state !== "object") throw new StoreError("the stored state is inconsistent: refusing");
      return d;
    }
    return got.state ? { gen: 0, state: got.state, legacy: true } : null;
  }
  async write(doc) {
    try {
      await this.storage.set({ [KEY]: doc });
    } catch (e) {
      throw new StoreError(`could not commit state generation ${doc.gen} (${e.message})`);
    }
    const back = await this.latest();
    if (!back || back.gen !== doc.gen || !sameState(back.state, doc.state)) throw new StoreError(`state generation ${doc.gen} did not stick`);
  }
  init(state) {
    return this.locks.request(LOCK, { mode: "exclusive" }, async () => {
      if (await this.latest()) return { ok: false, reason: "an anchor is already installed; reinstall the extension to change it" };
      await this.write({ gen: 1, state });
      return { ok: true, gen: 1, state };
    });
  }
  update(fn) {
    return this.locks.request(LOCK, { mode: "exclusive" }, async () => {
      const cur = await this.latest();
      if (!cur) throw new StoreError("no anchor installed");
      const r = await fn(cur.state, cur.gen);
      if (r.refuse !== void 0) return { ok: false, reason: r.refuse, gen: cur.gen };
      if (!cur.legacy && (r.same || sameState(r.state, cur.state))) return { ok: true, gen: cur.gen, state: cur.state, same: true };
      const doc = { gen: cur.gen + 1, state: r.state };
      await this.write(doc);
      return { ok: true, gen: doc.gen, state: doc.state };
    });
  }
};

// ext/options.src.js
var $ = (id) => document.getElementById(id);
var fields = ["policyKeyFp", "serialFloor", "releaseKeyFp", "policyUrl", "relayUrl", "appId"];
async function install(v) {
  const store = new ExtStore();
  const state = { ...initialState({ policyKeyFp: v.policyKeyFp, serialFloor: Number(v.serialFloor), releaseKeyFp: v.releaseKeyFp }), staged: null };
  const r = await store.init(state);
  if (!r.ok) {
    $("out").textContent = r.reason;
    if (v.resultUrl) await fetch(v.resultUrl, { method: "POST", body: JSON.stringify({ installed: false, reason: r.reason }), credentials: "omit" }).catch(() => {
    });
    return false;
  }
  await chrome.storage.local.set({ config: { policyUrl: v.policyUrl, relayUrl: v.relayUrl, appId: v.appId, resultUrl: v.resultUrl || null } });
  $("out").textContent = `Installed: ${JSON.stringify(state)}`;
  if (v.resultUrl) await fetch(v.resultUrl, { method: "POST", body: JSON.stringify({ installed: true, anchor: { policyKeyFp: state.policyFp, serialFloor: state.serial, releaseKeyFp: state.releaseFp } }), credentials: "omit" }).catch(() => {
  });
  return true;
}
var q = new URLSearchParams(location.search);
if (q.get("install") === "1") install(Object.fromEntries([...fields, "resultUrl"].map((k) => [k, q.get(k)]))).catch((e) => {
  $("out").textContent = e.message;
  if (q.get("resultUrl")) fetch(q.get("resultUrl"), { method: "POST", body: JSON.stringify({ installed: false, reason: e.message }), credentials: "omit" }).catch(() => {
  });
});
$("f").addEventListener("submit", (ev) => {
  ev.preventDefault();
  install(Object.fromEntries(fields.map((k) => [k, $(k).value.trim()]))).catch((e) => {
    $("out").textContent = e.message;
  });
});
